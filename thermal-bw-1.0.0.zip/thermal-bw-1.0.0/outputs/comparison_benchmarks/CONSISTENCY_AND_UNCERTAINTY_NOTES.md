# Consistency and uncertainty notes

## Confirmed implementation checks

1. **Reference calculation**  
   The direct reference remains the original `exact.py` isotropic blackbody Breit-Wheeler quadrature. This is the Gould-Schreder/Breit-Wheeler reference integral, not a shortcut.

2. **Monochromatic delta angular average**  
   The delta shortcuts use a fixed 96-point Gauss-Legendre angular average. I cross-checked representative points against a direct `scipy.integrate.quad` angular integral. Relative differences were about `1e-7` to `3e-7` for nonzero cases, so the shortcut benchmark errors are not caused by the fixed angular quadrature.

3. **Planck high-energy tail**  
   The threshold-tail model uses the exact series identity
   
   \[
   \int_{u_0}^{\infty}\frac{u^2}{e^u-1}\,du
   =\sum_{n=1}^{\infty}e^{-nu_0}\left(\frac{u_0^2}{n}+\frac{2u_0}{n^2}+\frac{2}{n^3}\right).
   \]
   
   This was checked against numerical quadrature at representative `u0 = 0, 0.1, 1, 10, 50`; relative differences were at machine precision.
