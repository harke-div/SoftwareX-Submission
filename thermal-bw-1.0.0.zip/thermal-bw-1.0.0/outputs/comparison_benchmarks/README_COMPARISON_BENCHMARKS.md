# Comparison benchmark outputs

This directory contains benchmark and demonstration products intended to strengthen the manuscript as an astronomical-computing/methods paper.

## Main files

- `comparison_grid_metrics.csv`: deterministic-grid accuracy/pathology summary.
- `comparison_holdout_metrics.csv`: random-holdout accuracy/pathology summary.
- `comparison_holdout_points.csv`: per-point holdout predictions and errors.
- `comparison_benchmark_summary.json`: machine-readable benchmark summary and interpretation warnings.
- `holdout_error_cdf.png`: cumulative error comparison across shortcut/surrogate methods.
- `scatter_exact_vs_*.png`: exact-vs-predicted scatter checks.
- `optical_depth_demo_points.csv`: optical-depth spectra for simple compact-source demonstrations.
- `optical_depth_demo_summary.json`: optical-depth error metrics.
- `optical_depth_demo_tau.png`: exact vs fit optical-depth spectra.
- `optical_depth_demo_error.png`: propagated tau relative error.
