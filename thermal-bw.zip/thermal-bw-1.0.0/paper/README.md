# Paper files

This folder contains a rendered draft of the SoftwareX manuscript for reference. The software release itself is usable independently through the package in `src/thermal_bw/`.
