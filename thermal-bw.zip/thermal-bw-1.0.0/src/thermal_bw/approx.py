"""Fast analytic surrogate for isotropic thermal Breit--Wheeler opacity."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

from .constants import ME_C2_KEV

# Published parameter vector for the 100x100 validation fit.
# Internal form is [logA, logb, logc, logd, p, a, q, r].
DEFAULT_PARAMS = np.array([
    -7.917834848488695,
    27.631021115928547,
    -1.3118921465454303,
    -7.488717284937159,
    0.67035,
    0.97883,
    1.00379,
    -5.0,
], dtype=float)

DOMAIN_E_MEV = (0.3, 30.0)
DOMAIN_KT_KEV = (5.0, 300.0)
ALPHA_FLOOR_CM_INV = 1e-25


@dataclass(frozen=True)
class FitParameters:
    """Named physical-space parameters for the analytic surrogate."""

    A: float
    b: float
    c: float
    d: float
    p: float
    a: float
    q: float
    r: float


def unpack_params(params: Iterable[float] = DEFAULT_PARAMS) -> FitParameters:
    """Convert the internal log-parameter vector to named physical parameters."""
    logA, logb, logc, logd, p, a, q, r = [float(x) for x in params]
    return FitParameters(
        A=float(np.exp(logA)),
        b=float(np.exp(logb)),
        c=float(np.exp(logc)),
        d=float(np.exp(logd)),
        p=float(p),
        a=float(a),
        q=float(q),
        r=float(r),
    )


def alpha_model(E_keV, kT_keV, params: Iterable[float] = DEFAULT_PARAMS):
    """Evaluate the analytic surrogate with energies supplied in keV.

    Parameters
    ----------
    E_keV : float or array-like
        Test-photon energy in keV.
    kT_keV : float or array-like
        Thermal energy scale of the blackbody target field in keV.
    params : iterable of float, optional
        Internal parameter vector [logA, logb, logc, logd, p, a, q, r].

    Returns
    -------
    float or numpy.ndarray
        Absorption coefficient in cm^-1. Broadcasting follows NumPy rules.
    """
    fp = unpack_params(params)
    E_keV = np.asarray(E_keV, dtype=float)
    kT_keV = np.asarray(kT_keV, dtype=float)

    eta = (E_keV / ME_C2_KEV) * (kT_keV / ME_C2_KEV)
    eta_pos = np.maximum(eta, 1e-300)

    suppression = np.exp(-((fp.a / eta_pos) ** fp.q))
    transition = (eta_pos ** (fp.p - 1.0)) * np.log1p(fp.b * eta_pos)
    denominator = 1.0 + fp.c * (eta_pos ** fp.p) * ((1.0 + fp.d * eta_pos) ** fp.r)

    out = fp.A * (kT_keV ** 3) * suppression * transition / denominator
    return np.maximum(out, 0.0)


def alpha_fit(E_MeV, kT_keV, params: Iterable[float] = DEFAULT_PARAMS):
    """Evaluate the published analytic opacity surrogate.

    Parameters
    ----------
    E_MeV : float or array-like
        Test-photon energy in MeV.
    kT_keV : float or array-like
        Thermal energy scale in keV.
    params : iterable of float, optional
        Internal parameter vector. The default is the published 100x100 fit.

    Returns
    -------
    float or numpy.ndarray
        Absorption coefficient alpha_gamma-gamma in cm^-1.

    Notes
    -----
    The validated domain is E = 0.3--30 MeV and kT = 5--300 keV. Values outside
    this domain are allowed by the function but are not validated to the same standard.
    """
    return alpha_model(np.asarray(E_MeV, dtype=float) * 1.0e3, kT_keV, params=params)


def within_validated_domain(E_MeV, kT_keV):
    """Return a boolean mask indicating whether inputs lie in the validated domain."""
    E = np.asarray(E_MeV, dtype=float)
    T = np.asarray(kT_keV, dtype=float)
    return (
        (E >= DOMAIN_E_MEV[0])
        & (E <= DOMAIN_E_MEV[1])
        & (T >= DOMAIN_KT_KEV[0])
        & (T <= DOMAIN_KT_KEV[1])
    )
