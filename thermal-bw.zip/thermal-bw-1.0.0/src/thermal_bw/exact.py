"""Direct quadrature reference for isotropic thermal Breit--Wheeler opacity."""
from __future__ import annotations

import math

import numpy as np
from scipy import integrate

from .constants import C_CGS, H_CGS, KEV_TO_ERG, ME_C2_KEV, PI, SIGMA_T


def sigma_breit_wheeler(beta: float) -> float:
    """Breit--Wheeler gamma-gamma -> e+e- cross section in cm^2."""
    if beta <= 0.0:
        return 0.0
    if beta >= 1.0:
        beta = 1.0 - 1e-15
    b2 = beta * beta
    one_minus_b2 = 1.0 - b2
    lnterm = math.log((1.0 + beta) / (1.0 - beta))
    bracket = (3.0 - beta**4) * lnterm - 2.0 * beta * (2.0 - b2)
    return (3.0 / 16.0) * SIGMA_T * one_minus_b2 * bracket


def blackbody_photon_density_per_energy(eps_erg: float, kT_erg: float) -> float:
    """Blackbody photon number density per unit energy in cm^-3 erg^-1."""
    if eps_erg <= 0.0 or kT_erg <= 0.0:
        return 0.0
    x = eps_erg / kT_erg
    denom = math.expm1(x)
    if denom == 0.0:
        return 0.0
    prefactor = (8.0 * PI) / (H_CGS**3 * C_CGS**3)
    return prefactor * eps_erg**2 / denom


def alpha_exact_keV(
    E_keV: float,
    kT_keV: float,
    *,
    u_max: float = 80.0,
    epsabs: float = 0.0,
    epsrel: float = 3e-4,
) -> float:
    """Direct quadrature opacity for E and kT supplied in keV.

    Returns alpha_gamma-gamma in cm^-1. This routine is intentionally slow and
    is intended for reference checks and benchmark generation, not for large sweeps.
    """
    if E_keV <= 0.0 or kT_keV <= 0.0:
        return 0.0

    x = E_keV / ME_C2_KEV
    kT_erg = kT_keV * KEV_TO_ERG

    def inner_eps(mu: float) -> float:
        one_minus_mu = 1.0 - mu
        if one_minus_mu <= 0.0:
            return 0.0
        y_thr = 2.0 / (x * one_minus_mu)
        eps_thr_erg = y_thr * ME_C2_KEV * KEV_TO_ERG
        u_thr = eps_thr_erg / kT_erg
        if u_thr >= u_max:
            return 0.0

        def integrand_u(u: float) -> float:
            eps_erg = u * kT_erg
            y = (eps_erg / KEV_TO_ERG) / ME_C2_KEV
            s = x * y * one_minus_mu
            if s <= 2.0:
                return 0.0
            beta = math.sqrt(1.0 - 2.0 / s)
            sigma = sigma_breit_wheeler(beta)
            n_eps = blackbody_photon_density_per_energy(eps_erg, kT_erg)
            return n_eps * sigma * kT_erg

        val, _ = integrate.quad(
            integrand_u, u_thr, u_max, epsabs=epsabs, epsrel=epsrel, limit=200
        )
        return val

    def integrand_mu(mu: float) -> float:
        return 0.5 * (1.0 - mu) * inner_eps(mu)

    val, _ = integrate.quad(
        integrand_mu, -1.0, 1.0, epsabs=epsabs, epsrel=epsrel, limit=200
    )
    return float(val)


def alpha_exact(E_MeV: float, kT_keV: float, **kwargs) -> float:
    """Direct quadrature opacity for E in MeV and kT in keV."""
    return alpha_exact_keV(float(E_MeV) * 1.0e3, float(kT_keV), **kwargs)


def alpha_grid(E_MeV, kT_keV, **kwargs) -> np.ndarray:
    """Compute direct quadrature on a grid. Returns shape (len(kT), len(E))."""
    E_MeV = np.asarray(E_MeV, dtype=float)
    kT_keV = np.asarray(kT_keV, dtype=float)
    out = np.zeros((len(kT_keV), len(E_MeV)), dtype=float)
    for i, T in enumerate(kT_keV):
        for j, E in enumerate(E_MeV):
            out[i, j] = alpha_exact(float(E), float(T), **kwargs)
    return out
