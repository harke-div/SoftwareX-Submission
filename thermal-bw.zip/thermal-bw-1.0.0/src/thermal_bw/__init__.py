"""thermal-bw: exact and approximate thermal Breit--Wheeler opacity."""
from __future__ import annotations

from .approx import (
    ALPHA_FLOOR_CM_INV,
    DEFAULT_PARAMS,
    DOMAIN_E_MEV,
    DOMAIN_KT_KEV,
    FitParameters,
    alpha_fit,
    alpha_model,
    unpack_params,
    within_validated_domain,
)
from .exact import alpha_exact, alpha_exact_keV, alpha_grid, sigma_breit_wheeler

__all__ = [
    "ALPHA_FLOOR_CM_INV",
    "DEFAULT_PARAMS",
    "DOMAIN_E_MEV",
    "DOMAIN_KT_KEV",
    "FitParameters",
    "alpha_fit",
    "alpha_model",
    "alpha_exact",
    "alpha_exact_keV",
    "alpha_grid",
    "sigma_breit_wheeler",
    "unpack_params",
    "within_validated_domain",
]

__version__ = "1.0.0"
