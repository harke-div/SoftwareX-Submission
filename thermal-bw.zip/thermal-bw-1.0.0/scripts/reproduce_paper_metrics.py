#!/usr/bin/env python3
"""Quick reproduction of manuscript headline values from archived outputs.

This script reads the published metrics JSON and writes a compact report. It is
intended as a lightweight check. The full 100 x 100 exact-grid regeneration is
available through the legacy fitting scripts, but it is slow because exact
quadrature is intentionally expensive.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from thermal_bw import DEFAULT_PARAMS, unpack_params


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--metrics", default="outputs/published_100x100/paper_metrics.json")
    parser.add_argument("--outdir", default="outputs/recomputed_quick")
    args = parser.parse_args()

    metrics_path = Path(args.metrics)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    metrics = json.loads(metrics_path.read_text())
    params = unpack_params(DEFAULT_PARAMS)

    lines = []
    lines.append("thermal-bw headline validation summary")
    lines.append("=======================================")
    lines.append("")
    lines.append("Published physical-space fit parameters:")
    for name in ["A", "b", "c", "d", "p", "a", "q", "r"]:
        lines.append(f"  {name} = {getattr(params, name):.12g}")
    lines.append("")
    lines.append("Dense-grid metrics:")
    for key, value in metrics["dense_grid"].items():
        lines.append(f"  {key}: {value}")
    lines.append("")
    lines.append("Monte Carlo metrics:")
    for key, value in metrics["monte_carlo_5000"].items():
        lines.append(f"  {key}: {value}")
    lines.append("")
    lines.append("Speed benchmark:")
    for key, value in metrics["speed"].items():
        lines.append(f"  {key}: {value}")

    report = "\n".join(lines) + "\n"
    (outdir / "headline_metrics_report.txt").write_text(report)
    print(report)


if __name__ == "__main__":
    main()
