#!/usr/bin/env python3
"""
comparison benchmark suite for the thermal Breit-Wheeler opacity paper.

This script adds:
  1. shortcut/model comparison benchmarks against the exact isotropic blackbody integral,
  2. Chebyshev log-polynomial surrogate checks,
  3. physical-pathology diagnostics (negative opacity, hard zeros, severe over/under-prediction),
  4. compact-source optical-depth demonstrations,
  5. CSV/JSON summaries and manuscript-ready plots.

It is intentionally conservative: Gould & Schreder/Breit-Wheeler quadrature is the reference,
not a shortcut. Delta/threshold formulas are diagnostic crude estimates, not claimed as exact
literature replacements for the thermal blackbody integral.
"""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
from typing import Callable, Dict, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from numpy.polynomial.chebyshev import chebvander2d, chebval2d
from scipy import integrate

from thermal_bw.approx import alpha_model
from thermal_bw.constants import ME_C2_KEV, SIGMA_T, H_CGS, C_CGS, KEV_TO_ERG, PI
from thermal_bw.exact import alpha_exact_keV as alpha_gg, sigma_breit_wheeler

ZETA3 = 1.2020569031595942854
RAD_A_CGS = 7.565733250033928e-15  # radiation constant, erg cm^-3 K^-4; not used directly


def load_published_params(repo: Path) -> np.ndarray:
    p = repo / "outputs" / "published_100x100" / "fit_params.json"
    with p.open() as f:
        return np.array(json.load(f)["params"], dtype=float)


def blackbody_number_density(kT_keV: float) -> float:
    """Total blackbody photon number density [cm^-3]."""
    kT_erg = kT_keV * KEV_TO_ERG
    return (16.0 * PI * ZETA3 / (H_CGS**3 * C_CGS**3)) * kT_erg**3


def blackbody_energy_density(kT_keV: float) -> float:
    """Total blackbody energy density [erg cm^-3] in energy-units kT."""
    # u = a T^4 = 8*pi^5/(15 h^3 c^3) (kT)^4
    kT_erg = kT_keV * KEV_TO_ERG
    return (8.0 * PI**5 / (15.0 * H_CGS**3 * C_CGS**3)) * kT_erg**4


def planck_tail_number_density(kT_keV: float, eps_min_keV: float) -> float:
    """Number density above eps_min [cm^-3].

    Uses the rapidly convergent expansion
    integral_u0^inf u^2/(exp(u)-1) du = sum_n exp(-n*u0)*(u0^2/n + 2*u0/n^2 + 2/n^3).
    This is equivalent to the Planck tail integral and avoids thousands of slow quadratures.
    """
    if eps_min_keV <= 0:
        return blackbody_number_density(kT_keV)
    u0 = eps_min_keV / kT_keV
    if u0 > 300:
        return 0.0
    kT_erg = kT_keV * KEV_TO_ERG
    pref = (8.0 * PI / (H_CGS**3 * C_CGS**3)) * kT_erg**3
    # choose nmax enough for small u0; for u0=0 this gives 2*zeta(3) to high accuracy
    if u0 < 1e-10:
        tail = 2.0 * ZETA3
    else:
        nmax = int(max(60, min(20000, math.ceil(40.0/u0))))
        n = np.arange(1, nmax+1, dtype=float)
        tail = np.sum(np.exp(-n*u0) * (u0*u0/n + 2.0*u0/(n*n) + 2.0/(n*n*n)))
    return float(pref * tail)


# Fixed Gauss-Legendre rule for monochromatic angular shortcuts.
_GL_X, _GL_W = np.polynomial.legendre.leggauss(96)

def mono_isotropic_alpha(E_keV: float, eps_eff_keV: float, n_eff_cm3: float) -> float:
    """Opacity for an isotropic monochromatic photon gas preserving chosen n_eff.

    This is a diagnostic shortcut. The angular average is evaluated with fixed
    Gauss-Legendre quadrature rather than scipy.quad for speed.
    """
    if E_keV <= 0 or eps_eff_keV <= 0 or n_eff_cm3 <= 0:
        return 0.0
    x = E_keV / ME_C2_KEV
    y = eps_eff_keV / ME_C2_KEV
    if x*y*2.0 <= 2.0:
        return 0.0
    mu_max = min(1.0 - 2.0/(x*y), 1.0)
    if mu_max <= -1.0:
        return 0.0
    a, b = -1.0, mu_max
    mu = 0.5*(b-a)*_GL_X + 0.5*(a+b)
    s = x*y*(1.0 - mu)
    valid = s > 2.0
    vals = np.zeros_like(mu)
    if np.any(valid):
        beta = np.sqrt(np.maximum(0.0, 1.0 - 2.0/s[valid]))
        # vectorized Breit-Wheeler cross-section
        beta = np.minimum(beta, 1.0 - 1e-15)
        b2 = beta*beta
        one_minus_b2 = 1.0 - b2
        lnterm = np.log((1.0 + beta)/(1.0 - beta))
        bracket = (3.0 - beta**4)*lnterm - 2.0*beta*(2.0 - b2)
        sig = (3.0/16.0)*SIGMA_T*one_minus_b2*bracket
        vals[valid] = 0.5*(1.0 - mu[valid])*sig
    integral = 0.5*(b-a)*np.sum(_GL_W*vals)
    return float(n_eff_cm3 * integral)


def delta_model(E_keV: float, kT_keV: float, mode: str) -> float:
    """Representative monochromatic/delta shortcuts for blackbody target."""
    if mode == "delta_number_peak_preserve_number":
        eps_eff = 1.593624260 * kT_keV  # maximum of u^2/(exp(u)-1)
        n_eff = blackbody_number_density(kT_keV)
    elif mode == "delta_number_mean_preserve_number":
        eps_eff = 2.701178034 * kT_keV  # <epsilon>/kT for photon number distribution
        n_eff = blackbody_number_density(kT_keV)
    elif mode == "delta_energy_peak_preserve_number":
        eps_eff = 2.821439372 * kT_keV  # maximum of u^3/(exp(u)-1)
        n_eff = blackbody_number_density(kT_keV)
    elif mode == "delta_energy_peak_preserve_energy":
        eps_eff = 2.821439372 * kT_keV
        n_eff = blackbody_energy_density(kT_keV) / (eps_eff * KEV_TO_ERG)
    else:
        raise ValueError(mode)
    return mono_isotropic_alpha(E_keV, eps_eff, n_eff)


def threshold_tail_model(E_keV: float, kT_keV: float, sigma_factor: float = 0.2) -> float:
    """Crude head-on threshold-tail estimate: sigma_factor*sigma_T*n(eps>eps_thr_headon)."""
    eps_thr = (ME_C2_KEV**2) / E_keV  # because head-on max gives eps_thr = me^2/E in this convention
    return sigma_factor * SIGMA_T * planck_tail_number_density(kT_keV, eps_thr)


def alpha_gg_wien(E_keV: float, kT_keV: float, u_max: float = 80.0, epsrel: float = 3e-4) -> float:
    """Exact angular integral but with Planck denominator replaced by exp(u). Useful only as Wien-tail asymptotic."""
    if E_keV <= 0.0 or kT_keV <= 0.0:
        return 0.0
    x = E_keV / ME_C2_KEV
    kT_erg = kT_keV * KEV_TO_ERG
    pref = (8.0 * PI) / (H_CGS**3 * C_CGS**3)

    def inner(mu: float) -> float:
        om = 1.0 - mu
        if om <= 0:
            return 0.0
        y_thr = 2.0 / (x * om)
        eps_thr_erg = y_thr * ME_C2_KEV * KEV_TO_ERG
        u_thr = eps_thr_erg / kT_erg
        if u_thr >= u_max:
            return 0.0
        def fu(u: float) -> float:
            eps_erg = u * kT_erg
            y = (eps_erg / KEV_TO_ERG) / ME_C2_KEV
            s = x*y*om
            if s <= 2:
                return 0.0
            beta = math.sqrt(1.0 - 2.0/s)
            n_wien = pref * eps_erg**2 * math.exp(-u)
            return n_wien * sigma_breit_wheeler(beta) * kT_erg
        val, _ = integrate.quad(fu, u_thr, u_max, epsabs=0.0, epsrel=epsrel, limit=200)
        return val

    def fmu(mu: float) -> float:
        return 0.5 * (1.0 - mu) * inner(mu)
    val, _ = integrate.quad(fmu, -1.0, 1.0, epsabs=0.0, epsrel=epsrel, limit=200)
    return float(val)


def exact_grid(E_vals: np.ndarray, T_vals: np.ndarray, epsrel: float, cache: Path) -> np.ndarray:
    if cache.exists():
        data = np.load(cache)
        if np.allclose(data["E"], E_vals) and np.allclose(data["T"], T_vals):
            return data["alpha"]
    out = np.zeros((len(T_vals), len(E_vals)))
    for i, T in enumerate(T_vals):
        print(f"exact grid row {i+1}/{len(T_vals)} kT={T:.3g} keV", flush=True)
        for j, E in enumerate(E_vals):
            out[i, j] = alpha_gg(float(E), float(T), epsrel=epsrel)
    np.savez(cache, E=E_vals, T=T_vals, alpha=out)
    return out


def scale_to_cheb(x: np.ndarray, xmin: float, xmax: float) -> np.ndarray:
    return 2*(x - xmin)/(xmax - xmin) - 1


def fit_cheb(E_grid: np.ndarray, T_grid: np.ndarray, alpha: np.ndarray, degree: int, alpha_floor: float) -> Dict:
    logE = np.log10(E_grid)
    logT = np.log10(T_grid)
    LE, LT = np.meshgrid(logE, logT)
    mask = alpha > alpha_floor
    xmin, xmax = logE.min(), logE.max()
    ymin, ymax = logT.min(), logT.max()
    X = scale_to_cheb(LE[mask], xmin, xmax)
    Y = scale_to_cheb(LT[mask], ymin, ymax)
    z = np.log10(alpha[mask])
    V = chebvander2d(X, Y, [degree, degree])
    coef_flat, *_ = np.linalg.lstsq(V, z, rcond=None)
    coef = coef_flat.reshape((degree+1, degree+1))
    return {"coef": coef, "degree": degree, "logE_min": xmin, "logE_max": xmax, "logT_min": ymin, "logT_max": ymax, "alpha_floor": alpha_floor}


def eval_cheb(E_keV, T_keV, fit: Dict) -> np.ndarray:
    E = np.asarray(E_keV, dtype=float)
    T = np.asarray(T_keV, dtype=float)
    X = scale_to_cheb(np.log10(E), fit["logE_min"], fit["logE_max"])
    Y = scale_to_cheb(np.log10(T), fit["logT_min"], fit["logT_max"])
    z = chebval2d(X, Y, fit["coef"])
    return 10**z


def metrics(y_true: np.ndarray, y_pred: np.ndarray, mask: np.ndarray) -> Dict[str, float]:
    yt = y_true[mask]
    yp = y_pred[mask]
    rel = np.abs(yp/yt - 1.0)
    ratio = yp/yt
    return {
        "N_retained": int(mask.sum()),
        "max_abs_relerr": float(np.max(rel)),
        "p99_abs_relerr": float(np.percentile(rel, 99)),
        "p95_abs_relerr": float(np.percentile(rel, 95)),
        "median_abs_relerr": float(np.median(rel)),
        "mean_abs_relerr": float(np.mean(rel)),
        "min_pred": float(np.min(yp)),
        "max_pred": float(np.max(yp)),
        "negative_count_all": int(np.sum(y_pred < 0)),
        "nonfinite_count_all": int(np.sum(~np.isfinite(y_pred))),
        "zero_in_retained_count": int(np.sum(yp == 0)),
        "under_by_1e6_count": int(np.sum(ratio < 1e-6)),
        "over_by_1e6_count": int(np.sum(ratio > 1e6)),
    }


def make_comparison_plots(df_holdout: pd.DataFrame, outdir: Path) -> None:
    # Error distribution comparison excluding extremely huge tail in x display by using log x.
    methods = [m for m in df_holdout["method"].unique() if m != "exact"]
    plt.figure(figsize=(8,5))
    for method in methods:
        sub = df_holdout[df_holdout.method == method]
        rel = np.sort(sub.abs_relerr.values)
        rel = rel[np.isfinite(rel)]
        if len(rel) == 0:
            continue
        y = np.linspace(0,1,len(rel))
        plt.plot(rel, y, label=method.replace("_", " "))
    plt.xscale("log")
    plt.xlabel("absolute relative error")
    plt.ylabel("cumulative fraction")
    plt.title("Random-holdout shortcut/surrogate comparison")
    plt.legend(fontsize=7)
    plt.tight_layout()
    plt.savefig(outdir/"holdout_error_cdf.png", dpi=220)
    plt.close()

    # Scatter exact vs approximate for selected methods.
    selected = ["closed_form", "delta_number_mean_preserve_number", "threshold_tail", "cheb12"]
    for method in selected:
        sub = df_holdout[df_holdout.method == method].copy()
        if sub.empty:
            continue
        plt.figure(figsize=(5.5,5))
        plt.scatter(sub.alpha_exact, sub.alpha_pred, s=10, alpha=0.6)
        lims = [min(sub.alpha_exact.min(), sub.alpha_pred[sub.alpha_pred>0].min() if np.any(sub.alpha_pred>0) else sub.alpha_exact.min()),
                max(sub.alpha_exact.max(), sub.alpha_pred.max())]
        plt.plot(lims, lims, linestyle="--")
        plt.xscale("log"); plt.yscale("log")
        plt.xlabel("exact alpha [cm^-1]")
        plt.ylabel("predicted alpha [cm^-1]")
        plt.title(method.replace("_", " "))
        plt.tight_layout()
        plt.savefig(outdir/f"scatter_exact_vs_{method}.png", dpi=220)
        plt.close()


def run_benchmarks(repo: Path, outdir: Path, n_grid: int, n_holdout: int, epsrel: float, alpha_floor: float, seed: int) -> Dict:
    outdir.mkdir(parents=True, exist_ok=True)
    params = load_published_params(repo)
    rng = np.random.default_rng(seed)

    E_grid = np.logspace(np.log10(300.0), np.log10(30000.0), n_grid)
    T_grid = np.logspace(np.log10(5.0), np.log10(300.0), n_grid)
    alpha_ex = exact_grid(E_grid, T_grid, epsrel, outdir/f"exact_grid_{n_grid}x{n_grid}.npz")
    EE, TT = np.meshgrid(E_grid, T_grid)
    mask = alpha_ex > alpha_floor

    # Cheb fits on exact grid.
    cheb8 = fit_cheb(E_grid, T_grid, alpha_ex, 8, alpha_floor)
    cheb12 = fit_cheb(E_grid, T_grid, alpha_ex, 12, alpha_floor)
    np.savez(outdir/"chebyshev_fits.npz", cheb8_coef=cheb8["coef"], cheb12_coef=cheb12["coef"],
             logE_min=cheb8["logE_min"], logE_max=cheb8["logE_max"], logT_min=cheb8["logT_min"], logT_max=cheb8["logT_max"])

    methods: Dict[str, Callable[[np.ndarray, np.ndarray], np.ndarray]] = {}
    methods["closed_form"] = lambda E,T: alpha_model(E, T, params)
    for m in ["delta_number_peak_preserve_number", "delta_number_mean_preserve_number", "delta_energy_peak_preserve_number", "delta_energy_peak_preserve_energy"]:
        methods[m] = np.vectorize(lambda E,T, mm=m: delta_model(float(E), float(T), mm))
    methods["threshold_tail"] = np.vectorize(lambda E,T: threshold_tail_model(float(E), float(T)))
    methods["cheb8"] = lambda E,T: eval_cheb(E,T,cheb8)
    methods["cheb12"] = lambda E,T: eval_cheb(E,T,cheb12)

    grid_rows = []
    grid_point_rows = []
    for name, fn in methods.items():
        print(f"evaluating grid method {name}", flush=True)
        pred = fn(EE, TT)
        met = metrics(alpha_ex, pred, mask)
        met["method"] = name
        met["sample"] = f"deterministic_{n_grid}x{n_grid}"
        grid_rows.append(met)
        rel = np.full(alpha_ex.shape, np.nan)
        rel[mask] = np.abs(pred[mask]/alpha_ex[mask] - 1.0)
        for E,T,a,p,r in zip(EE[mask].ravel(), TT[mask].ravel(), alpha_ex[mask].ravel(), pred[mask].ravel(), rel[mask].ravel()):
            grid_point_rows.append({"method":name,"E_keV":E,"kT_keV":T,"alpha_exact":a,"alpha_pred":p,"abs_relerr":r})

    pd.DataFrame(grid_rows).to_csv(outdir/"comparison_grid_metrics.csv", index=False)
    pd.DataFrame(grid_point_rows).to_csv(outdir/"comparison_grid_points.csv", index=False)

    # Holdout exact values.
    E_h = 10**rng.uniform(np.log10(300.0), np.log10(30000.0), n_holdout)
    T_h = 10**rng.uniform(np.log10(5.0), np.log10(300.0), n_holdout)
    cache_h = outdir/f"exact_holdout_{n_holdout}.npz"
    if cache_h.exists():
        hdata = np.load(cache_h)
        E_h, T_h, alpha_h = hdata["E"], hdata["T"], hdata["alpha"]
    else:
        alpha_h = np.zeros(n_holdout)
        for i,(E,T) in enumerate(zip(E_h,T_h)):
            if (i+1) % max(1, n_holdout//20) == 0:
                print(f"exact holdout {i+1}/{n_holdout}", flush=True)
            alpha_h[i] = alpha_gg(float(E), float(T), epsrel=epsrel)
        np.savez(cache_h, E=E_h, T=T_h, alpha=alpha_h)
    mask_h = alpha_h > alpha_floor

    holdout_rows = []
    holdout_points = []
    for name, fn in methods.items():
        pred = fn(E_h, T_h)
        met = metrics(alpha_h, pred, mask_h)
        met["method"] = name
        met["sample"] = f"random_holdout_{n_holdout}"
        holdout_rows.append(met)
        rel = np.full_like(alpha_h, np.nan)
        rel[mask_h] = np.abs(pred[mask_h]/alpha_h[mask_h] - 1.0)
        for E,T,a,p,r in zip(E_h[mask_h], T_h[mask_h], alpha_h[mask_h], pred[mask_h], rel[mask_h]):
            holdout_points.append({"method":name,"E_keV":E,"kT_keV":T,"alpha_exact":a,"alpha_pred":p,"abs_relerr":r})

    # Wien subset: evaluate only where u_thr tends to be high-ish; diagnostic, not full benchmark.
    idx = rng.choice(np.where(mask_h)[0], size=min(60, int(mask_h.sum())), replace=False)
    wien_rows = []
    for i in idx:
        pred = alpha_gg_wien(float(E_h[i]), float(T_h[i]), epsrel=epsrel)
        rel = abs(pred/alpha_h[i] - 1.0)
        wien_rows.append({"method":"wien_tail", "E_keV":E_h[i], "kT_keV":T_h[i], "alpha_exact":alpha_h[i], "alpha_pred":pred, "abs_relerr":rel})
    if wien_rows:
        wr = pd.DataFrame(wien_rows)
        met = {
            "N_retained": len(wr),
            "max_abs_relerr": float(wr.abs_relerr.max()),
            "p99_abs_relerr": float(np.percentile(wr.abs_relerr, 99)),
            "p95_abs_relerr": float(np.percentile(wr.abs_relerr, 95)),
            "median_abs_relerr": float(wr.abs_relerr.median()),
            "mean_abs_relerr": float(wr.abs_relerr.mean()),
            "min_pred": float(wr.alpha_pred.min()),
            "max_pred": float(wr.alpha_pred.max()),
            "negative_count_all": int((wr.alpha_pred<0).sum()),
            "nonfinite_count_all": int((~np.isfinite(wr.alpha_pred)).sum()),
            "zero_in_retained_count": int((wr.alpha_pred==0).sum()),
            "under_by_1e6_count": int(((wr.alpha_pred/wr.alpha_exact)<1e-6).sum()),
            "over_by_1e6_count": int(((wr.alpha_pred/wr.alpha_exact)>1e6).sum()),
            "method":"wien_tail", "sample":"random_subset_diagnostic"
        }
        holdout_rows.append(met)
        holdout_points += wien_rows

    df_hold_metrics = pd.DataFrame(holdout_rows)
    df_hold_points = pd.DataFrame(holdout_points)
    df_hold_metrics.to_csv(outdir/"comparison_holdout_metrics.csv", index=False)
    df_hold_points.to_csv(outdir/"comparison_holdout_points.csv", index=False)
    make_comparison_plots(df_hold_points, outdir)

    summary = {
        "settings": {"n_grid": n_grid, "n_holdout": n_holdout, "epsrel": epsrel, "alpha_floor": alpha_floor, "seed": seed},
        "interpretation_warnings": [
            "Gould-Schreder/Breit-Wheeler quadrature is the reference calculation, not a shortcut.",
            "Delta and threshold-tail formulas are representative crude estimates; do not call them exact literature approximations to the full blackbody opacity.",
            "Chebyshev surrogates are high-accuracy black-box interpolants inside the fitted rectangle; they do not replace the compact analytic closed-form claim."
        ],
        "grid_metrics": grid_rows,
        "holdout_metrics": holdout_rows,
    }
    with (outdir/"comparison_benchmark_summary.json").open("w") as f:
        json.dump(summary, f, indent=2)
    return summary


def optical_depth_demo(repo: Path, outdir: Path, epsrel: float) -> Dict:
    outdir.mkdir(parents=True, exist_ok=True)
    params = load_published_params(repo)
    E_vals = np.logspace(np.log10(300.0), np.log10(30000.0), 45)
    cases = [
        {"name":"constant_slab_kT30_L1e8", "kind":"constant", "kT0":30.0, "L_cm":1e8},
        {"name":"constant_slab_kT100_L1e7", "kind":"constant", "kT0":100.0, "L_cm":1e7},
        {"name":"cooling_profile_kT150_to_20_L1e8", "kind":"powerlaw", "kT0":150.0, "kT1":20.0, "L_cm":1e8, "zones":10},
    ]
    rows = []
    case_metrics = []
    for case in cases:
        print(f"optical depth case {case['name']}", flush=True)
        if case["kind"] == "constant":
            T_profile = np.array([case["kT0"]])
            dr = np.array([case["L_cm"]])
        else:
            z = np.linspace(0, 1, case["zones"])
            # Smooth monotonic cooling from kT0 to kT1 across slab.
            T_profile = case["kT0"] * (case["kT1"]/case["kT0"])**z
            dr = np.full_like(T_profile, case["L_cm"]/len(T_profile))
        for E in E_vals:
            a_exact_z = np.array([alpha_gg(float(E), float(T), epsrel=epsrel) for T in T_profile])
            a_fit_z = alpha_model(float(E), T_profile, params)
            tau_exact = float(np.sum(a_exact_z * dr))
            tau_fit = float(np.sum(a_fit_z * dr))
            rel = abs(tau_fit/tau_exact - 1.0) if tau_exact > 0 else np.nan
            rows.append({"case":case["name"], "E_keV":E, "tau_exact":tau_exact, "tau_fit":tau_fit, "abs_relerr_tau":rel})
    df = pd.DataFrame(rows)
    df.to_csv(outdir/"optical_depth_demo_points.csv", index=False)

    for cname, sub in df.groupby("case"):
        valid = sub.tau_exact > 0
        case_metrics.append({
            "case": cname,
            "max_tau_exact": float(sub.tau_exact.max()),
            "min_tau_exact": float(sub.tau_exact.min()),
            "max_abs_relerr_tau": float(sub.loc[valid,"abs_relerr_tau"].max()),
            "p99_abs_relerr_tau": float(np.percentile(sub.loc[valid,"abs_relerr_tau"], 99)),
            "median_abs_relerr_tau": float(sub.loc[valid,"abs_relerr_tau"].median()),
        })

    # Plot tau curves.
    plt.figure(figsize=(7.5,5.2))
    for cname, sub in df.groupby("case"):
        plt.plot(sub.E_keV/1000.0, sub.tau_exact, label=f"{cname} exact")
        plt.plot(sub.E_keV/1000.0, sub.tau_fit, linestyle="--", label=f"{cname} fit")
    plt.xscale("log"); plt.yscale("log")
    plt.xlabel("test-photon energy E [MeV]")
    plt.ylabel("optical depth tau")
    plt.title("Optical-depth demonstration: exact quadrature vs closed form")
    plt.legend(fontsize=6)
    plt.tight_layout()
    plt.savefig(outdir/"optical_depth_demo_tau.png", dpi=220)
    plt.close()

    plt.figure(figsize=(7.5,4.6))
    for cname, sub in df.groupby("case"):
        plt.plot(sub.E_keV/1000.0, sub.abs_relerr_tau, label=cname)
    plt.xscale("log"); plt.yscale("log")
    plt.xlabel("test-photon energy E [MeV]")
    plt.ylabel("absolute relative error in tau")
    plt.title("Optical-depth error propagated through simple source models")
    plt.legend(fontsize=7)
    plt.tight_layout()
    plt.savefig(outdir/"optical_depth_demo_error.png", dpi=220)
    plt.close()

    summary = {"cases": cases, "case_metrics": case_metrics,
               "limitations": "These are controlled demonstrations, not claimed as full physical models of a specific source."}
    with (outdir/"optical_depth_demo_summary.json").open("w") as f:
        json.dump(summary, f, indent=2)
    return summary


def write_notes(outdir: Path) -> None:
    text = """# Comparison benchmark outputs

This directory contains benchmark and demonstration products intended to strengthen the manuscript as an astronomical-computing/methods paper.

## Main files

- `comparison_grid_metrics.csv`: deterministic-grid accuracy/pathology summary.
- `comparison_holdout_metrics.csv`: random-holdout accuracy/pathology summary.
- `comparison_holdout_points.csv`: per-point holdout predictions and errors.
- `comparison_benchmark_summary.json`: machine-readable benchmark summary and interpretation warnings.
- `holdout_error_cdf.png`: cumulative error comparison across shortcut/surrogate methods.
- `scatter_exact_vs_*.png`: exact-vs-predicted scatter checks.
- `optical_depth_demo_points.csv`: optical-depth spectra for simple compact-source demonstrations.
- `optical_depth_demo_summary.json`: optical-depth error metrics.
- `optical_depth_demo_tau.png`: exact vs fit optical-depth spectra.
- `optical_depth_demo_error.png`: propagated tau relative error.

## Methodological caution

Gould & Schreder / Breit-Wheeler quadrature is treated as the direct reference, not as a shortcut approximation. Delta and threshold-tail models are included as representative crude fast estimates because they demonstrate what is lost when the full Planck and angular weighting are collapsed too aggressively. Chebyshev fits are included as black-box interpolation surrogates and should be framed separately from the compact analytic closed form.

## Suggested manuscript framing

The strongest claim supported by these files is not that the closed form is the mathematically most accurate surrogate possible. A Chebyshev interpolant can be more accurate inside the fitted box. The stronger and safer claim is:

> The proposed expression gives sub-percent accuracy while remaining compact, non-negative, branchless, physically scaled, and table-free. Crude monochromatic/threshold estimates show hard cutoff artifacts or order-unity-to-order-of-magnitude errors across the transition regime, while black-box polynomial interpolation trades interpretability and compactness for higher interpolation accuracy.
"""
    (outdir/"README_COMPARISON_BENCHMARK_OUTPUTS.md").write_text(text)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="outputs/comparison_benchmarks")
    ap.add_argument("--n-grid", type=int, default=50)
    ap.add_argument("--n-holdout", type=int, default=1000)
    ap.add_argument("--epsrel", type=float, default=3e-4)
    ap.add_argument("--alpha-floor", type=float, default=1e-25)
    ap.add_argument("--seed", type=int, default=20260507)
    args = ap.parse_args()
    repo = Path(__file__).resolve().parent
    outdir = repo / args.outdir
    outdir.mkdir(parents=True, exist_ok=True)
    comp = run_benchmarks(repo, outdir, args.n_grid, args.n_holdout, args.epsrel, args.alpha_floor, args.seed)
    opt = optical_depth_demo(repo, outdir, args.epsrel)
    write_notes(outdir)
    print("DONE")
    print(f"outputs: {outdir}")

if __name__ == "__main__":
    main()
