#!/usr/bin/env python3
"""
Compactness-normalized line-of-sight benchmark for the isotropic thermal
Breit-Wheeler absorption coefficient.

This is intended as a more astrophysically motivated use-case than arbitrary
slab lengths. It uses the standard compactness parameter for a radiation field,

    ell_rad = sigma_T * R * u_rad / (m_e c^2),

where u_rad is the radiation energy density. For a diluted blackbody with the
same spectral shape as a Planck distribution, n(eps)=W n_bb(eps,T), the opacity
coefficient and energy density both scale linearly with W. Therefore

    W R = ell_rad * m_e c^2 / (sigma_T * u_bb(T)),

and the optical depth through the zone is

    tau_gg(E; kT, ell_rad) = alpha_bb(E,kT) * ell_rad*m_e*c^2/(sigma_T*u_bb(T)).

This removes arbitrary choices of path length and normalization while preserving
the exact blackbody spectral-shape problem treated in the manuscript.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from thermal_bw.exact import alpha_exact_keV as alpha_gg
from thermal_bw.constants import SIGMA_T, KEV_TO_ERG, C_CGS, H_CGS
from thermal_bw.approx import alpha_model

# Constants
ME_C2_KEV = 511.0
ME_C2_ERG = ME_C2_KEV * KEV_TO_ERG
KB_CGS = 1.380649e-16
A_RAD = 7.565733250033928e-15  # erg cm^-3 K^-4

PARAMS = np.array([
    -7.917834848488695,
    27.631021115928547,
    -1.3118921465454303,
    -7.488717284937159,
    0.67035,
    0.97883,
    1.00379,
    -5.0,
], dtype=float)

OUT = Path("outputs/compactness_benchmark_suite")
OUT.mkdir(parents=True, exist_ok=True)


def u_blackbody_from_kT(kT_keV: float) -> float:
    """Blackbody radiation energy density [erg cm^-3] for kT in keV."""
    T_K = kT_keV * KEV_TO_ERG / KB_CGS
    return A_RAD * T_K**4


def compactness_column_factor(kT_keV: float, ell: float) -> float:
    """Return W*R [cm] for a diluted BB zone with compactness ell."""
    return ell * ME_C2_ERG / (SIGMA_T * u_blackbody_from_kT(kT_keV))


def relerr(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    return np.abs(b-a) / np.maximum(np.abs(a), 1e-300)


def summarize(arr):
    arr = np.asarray(arr, dtype=float)
    return {
        "N": int(arr.size),
        "max": float(np.max(arr)),
        "p99": float(np.percentile(arr, 99)),
        "p95": float(np.percentile(arr, 95)),
        "median": float(np.median(arr)),
        "mean": float(np.mean(arr)),
    }


def main():
    # Energy grid deliberately denser around the transition but still cheap enough.
    E_keV = np.geomspace(300.0, 30000.0, 80)
    kT_values = np.array([10.0, 30.0, 100.0, 300.0])
    ell_values = np.array([0.1, 1.0, 10.0, 100.0])

    rows = []
    # Exact alpha only needs to be computed once per (E,kT).
    alpha_cache = {}
    for kT in kT_values:
        for E in E_keV:
            a_ex = alpha_gg(float(E), float(kT), epsrel=3e-4)
            a_ap = float(alpha_model(float(E), float(kT), PARAMS))
            alpha_cache[(float(E), float(kT))] = (a_ex, a_ap)
            for ell in ell_values:
                WR = compactness_column_factor(float(kT), float(ell))
                tau_ex = a_ex * WR
                tau_ap = a_ap * WR
                rows.append({
                    "E_keV": float(E),
                    "E_MeV": float(E/1000.0),
                    "kT_keV": float(kT),
                    "ell_rad": float(ell),
                    "u_bb_erg_cm3": float(u_blackbody_from_kT(float(kT))),
                    "WR_cm": float(WR),
                    "alpha_exact_cm_inv": float(a_ex),
                    "alpha_approx_cm_inv": float(a_ap),
                    "tau_exact": float(tau_ex),
                    "tau_approx": float(tau_ap),
                    "relerr_tau": float(abs(tau_ap-tau_ex)/max(abs(tau_ex),1e-300)),
                })

    df = pd.DataFrame(rows)
    df.to_csv(OUT/"compactness_benchmark_points.csv", index=False)

    # Summary by kT and ell, only for tau values above a very tiny operational floor.
    # Relative errors in tau are equivalent to alpha errors, but this gives a direct use-case table.
    summary_rows = []
    for (kT, ell), g in df.groupby(["kT_keV", "ell_rad"]):
        mask = g["alpha_exact_cm_inv"].values > 1e-25
        er = g.loc[mask, "relerr_tau"].values
        tau = g.loc[mask, "tau_exact"].values
        if er.size:
            s = summarize(er)
            summary_rows.append({
                "kT_keV": kT,
                "ell_rad": ell,
                "N_retained": int(er.size),
                "tau_exact_min_retained": float(np.min(tau)),
                "tau_exact_max_retained": float(np.max(tau)),
                "max_relerr_tau": s["max"],
                "p99_relerr_tau": s["p99"],
                "median_relerr_tau": s["median"],
            })
    sdf = pd.DataFrame(summary_rows)
    sdf.to_csv(OUT/"compactness_benchmark_summary_by_case.csv", index=False)

    global_mask = df["alpha_exact_cm_inv"].values > 1e-25
    global_summary = summarize(df.loc[global_mask, "relerr_tau"].values)
    # Transparency boundary estimates: E where tau crosses 1 by log interpolation.
    boundary_rows = []
    for (kT, ell), g in df.groupby(["kT_keV", "ell_rad"]):
        gg = g.sort_values("E_keV")
        E = gg["E_MeV"].values
        tau = gg["tau_exact"].values
        # crossing from <1 to >1 or reverse; tau is usually monotonic-ish here but not assumed.
        idxs = np.where(np.diff(np.sign(tau - 1.0)) != 0)[0]
        if len(idxs) == 0:
            status = "always_below_1" if np.all(tau < 1.0) else "always_above_1"
            E_cross = np.nan
        else:
            i = idxs[0]
            # log-log interpolation if positive
            if tau[i] > 0 and tau[i+1] > 0:
                x0,x1 = np.log(E[i]), np.log(E[i+1])
                y0,y1 = np.log(tau[i]), np.log(tau[i+1])
                xc = x0 + (0.0-y0)*(x1-x0)/(y1-y0)
                E_cross = float(np.exp(xc))
            else:
                E_cross = float(E[i])
            status = "crosses_tau_1"
        boundary_rows.append({"kT_keV": float(kT), "ell_rad": float(ell), "status": status, "E_tau1_MeV": E_cross})
    bdf = pd.DataFrame(boundary_rows)
    bdf.to_csv(OUT/"compactness_tau1_boundaries.csv", index=False)

    with open(OUT/"compactness_benchmark_summary.json", "w") as f:
        json.dump({
            "definition": "ell_rad = sigma_T R u_rad/(m_e c^2); tau = alpha_bb * ell_rad*m_e*c^2/(sigma_T*u_bb)",
            "domain": {"E_keV": [300,30000], "kT_keV": kT_values.tolist(), "ell_rad": ell_values.tolist()},
            "retained_floor": "alpha_exact_cm_inv > 1e-25",
            "global_retained_error_summary": global_summary,
            "notes": [
                "This benchmark uses a compactness-normalized diluted-blackbody radiation column, not an arbitrary slab length.",
                "It is an astrophysical computing benchmark, not a source-specific GRB/blazar/corona model.",
                "Errors in tau equal errors in alpha because the compactness normalization multiplies exact and approximate coefficients by the same physical column factor.",
            ],
        }, f, indent=2)

    # Plot 1: tau spectra for ell=10.
    plt.figure(figsize=(7.2,5.0))
    ell_plot = 10.0
    for kT in kT_values:
        g = df[(df.kT_keV==kT) & (df.ell_rad==ell_plot)].sort_values("E_MeV")
        plt.loglog(g.E_MeV, g.tau_exact, label=f"exact kT={kT:g} keV")
        plt.loglog(g.E_MeV, g.tau_approx, linestyle="--", label=f"fit kT={kT:g} keV")
    plt.axhline(1.0, linestyle=":", linewidth=1)
    plt.xlabel("Test-photon energy E (MeV)")
    plt.ylabel(r"$\tau_{\gamma\gamma}$ at radiation compactness $\ell_{rad}=10$")
    plt.title("Compactness-normalized thermal opacity benchmark")
    plt.legend(fontsize=7, ncol=2)
    plt.tight_layout()
    plt.savefig(OUT/"compactness_tau_spectra_ell10.png", dpi=220)
    plt.close()

    # Plot 2: tau error spectra for all kT at ell=10.
    plt.figure(figsize=(7.2,4.6))
    for kT in kT_values:
        g = df[(df.kT_keV==kT) & (df.ell_rad==ell_plot)].sort_values("E_MeV")
        mask = g.alpha_exact_cm_inv > 1e-25
        plt.semilogx(g.loc[mask,"E_MeV"], 100*g.loc[mask,"relerr_tau"], label=f"kT={kT:g} keV")
    plt.xlabel("Test-photon energy E (MeV)")
    plt.ylabel("Relative error in optical depth (%)")
    plt.title("Line-of-sight accumulated error")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(OUT/"compactness_tau_error_ell10.png", dpi=220)
    plt.close()

    # Plot 3: tau=1 boundary table visualized.
    pivot = bdf.pivot(index="kT_keV", columns="ell_rad", values="E_tau1_MeV")
    plt.figure(figsize=(6.2,4.8))
    for ell in ell_values:
        y = bdf[bdf.ell_rad==ell].sort_values("kT_keV")
        ok = np.isfinite(y.E_tau1_MeV.values)
        if np.any(ok):
            plt.loglog(y.kT_keV.values[ok], y.E_tau1_MeV.values[ok], marker="o", label=f"ell={ell:g}")
    plt.xlabel("Thermal scale kT (keV)")
    plt.ylabel(r"Energy where $\tau_{\gamma\gamma}=1$ (MeV)")
    plt.title("Transparency boundary in compactness-normalized benchmark")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(OUT/"compactness_tau1_boundaries.png", dpi=220)
    plt.close()

    # README and manuscript insert draft.
    readme = f"""# Compactness-normalized benchmark suite

This suite replaces arbitrary optical-depth slabs with a compactness-normalized radiation-column benchmark.

Definition used:

    ell_rad = sigma_T R u_rad / (m_e c^2)

For a diluted blackbody spectral shape, alpha and u_rad scale linearly with dilution W, giving

    tau_gg(E; kT, ell_rad) = alpha_bb(E,kT) * ell_rad*m_e*c^2/(sigma_T*u_bb(kT)).

This benchmark is therefore tied to a standard compact-source radiation compactness rather than an arbitrary path length.
It is not intended as a full source-specific GRB/blazar/corona model.

Global retained-domain relative error summary for tau:

```json
{json.dumps(global_summary, indent=2)}
```

Main files:

- compactness_benchmark_points.csv: all alpha and tau values.
- compactness_benchmark_summary_by_case.csv: error summaries by kT and ell.
- compactness_tau1_boundaries.csv: energy where tau crosses 1 where present.
- compactness_tau_spectra_ell10.png: exact-vs-fit tau spectra.
- compactness_tau_error_ell10.png: percent tau errors.
- compactness_tau1_boundaries.png: tau=1 boundary plot.
"""
    (OUT/"README_COMPACTNESS_BENCHMARK.md").write_text(readme)

    draft = r"""
## Draft manuscript insertion: compactness-normalized opacity benchmark

To test whether the coefficient-level accuracy survives a more astrophysically relevant line-of-sight calculation, we also evaluate a compactness-normalized thermal radiation column.  We define a radiation compactness
\[
\ell_{\rm rad}=\frac{\sigma_{\rm T} R u_{\rm rad}}{m_e c^2},
\]
where \(u_{\rm rad}\) is the radiation energy density.  For a diluted blackbody field with the same spectral shape as a Planck distribution, both \(u_{\rm rad}\) and \(\alpha_{\gamma\gamma}\) scale linearly with the dilution factor.  The optical depth through the zone can therefore be written without choosing an arbitrary path length as
\[
\tau_{\gamma\gamma}(E;kT,\ell_{\rm rad})
= \alpha_{\gamma\gamma}^{\rm bb}(E,kT)
\frac{\ell_{\rm rad}m_e c^2}{\sigma_{\rm T}u_{\rm bb}(kT)}.
\]
This is not intended as a source-specific model of a GRB, blazar, or corona; it is a controlled compact-source opacity benchmark that tests the numerical surrogate in the line-of-sight form in which it would normally enter radiative-transfer calculations.

Across \(kT=10,30,100,300\) keV and \(\ell_{\rm rad}=0.1,1,10,100\), the retained-domain optical-depth errors are identical to the coefficient-level errors up to the common compactness normalization. The global retained-domain maximum, 99th-percentile, and median relative errors in \(\tau_{\gamma\gamma}\) are reported in the accompanying benchmark table. This confirms that the approximation does not accumulate additional error when inserted into a physically normalized opacity column.
"""
    (OUT/"MANUSCRIPT_INSERT_COMPACTNESS_BENCHMARK.md").write_text(draft)

    print("Wrote outputs to", OUT)
    print(json.dumps(global_summary, indent=2))

if __name__ == "__main__":
    main()
