#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math, random, time
from pathlib import Path
import numpy as np

from approx import alpha_model
from exact import alpha_gg

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fit-outdir", required=True, help="Folder containing fit_params.json (from fit_approx.py)")
    ap.add_argument("--Emin", type=float, default=300.0)
    ap.add_argument("--Emax", type=float, default=30000.0)
    ap.add_argument("--kTmin", type=float, default=5.0)
    ap.add_argument("--kTmax", type=float, default=300.0)
    ap.add_argument("--Nrand", type=int, default=80, help="Random validation points")
    ap.add_argument("--Ndense", type=int, default=40, help="Dense scan per axis for corner check")
    ap.add_argument("--alpha_min", type=float, default=1e-120, help="Ignore exact values below this (underflow/irrelevant)")
    ap.add_argument("--epsrel", type=float, default=3e-4, help="Exact integrator epsrel")
    ap.add_argument("--out", default="validation_report.txt")
    args = ap.parse_args()

    outdir = Path(args.fit_outdir)
    params = np.array(json.loads((outdir/"fit_params.json").read_text())["params"], dtype=float)

    rng = random.Random(0)

    def log_uniform(a,b):
        la, lb = math.log(a), math.log(b)
        return math.exp(la + (lb-la)*rng.random())

    # --- Random holdout validation ---
    rand_pts = [(log_uniform(args.Emin,args.Emax), log_uniform(args.kTmin,args.kTmax)) for _ in range(args.Nrand)]

    # --- Dense “corner” scan (captures where max error usually lives) ---
    # Two corners: (low kT, all E) and (low E, all kT) + a diagonal in eta
    E_dense = np.logspace(np.log10(args.Emin), np.log10(args.Emax), args.Ndense)
    T_dense = np.logspace(np.log10(args.kTmin), np.log10(args.kTmax), args.Ndense)

    corner_pts = []
    # low kT line
    corner_pts += [(float(E), float(args.kTmin)) for E in E_dense]
    # low E line
    corner_pts += [(float(args.Emin), float(T)) for T in T_dense]
    # diagonal in eta (choose eta spanning range)
    for s in np.linspace(0,1,args.Ndense):
        E = args.Emin * (args.Emax/args.Emin)**s
        T = args.kTmax * (args.kTmin/args.kTmax)**s
        corner_pts.append((float(E), float(T)))

    pts = rand_pts + corner_pts

    rows = []
    t0 = time.time()
    for (E, kT) in pts:
        exact = alpha_gg(E, kT, epsrel=args.epsrel)
        approx = float(alpha_model(E, kT, params))
        if not (np.isfinite(exact) and np.isfinite(approx) and approx > 0):
            rows.append((E,kT,exact,approx,np.nan,np.nan,"BAD_NONFINITE_OR_NONPOS"))
            continue
        if exact <= args.alpha_min:
            rows.append((E,kT,exact,approx,np.nan,np.nan,"IGNORED_UNDERFLOW"))
            continue
        rel = abs((approx-exact)/exact)
        loge = abs(math.log(approx) - math.log(exact))
        rows.append((E,kT,exact,approx,rel,loge,"OK"))
    t1 = time.time()

    ok = [r for r in rows if r[6]=="OK"]
    ignored = sum(1 for r in rows if r[6]=="IGNORED_UNDERFLOW")
    bad = sum(1 for r in rows if r[6]=="BAD_NONFINITE_OR_NONPOS")

    rels = np.array([r[4] for r in ok], dtype=float)
    loges = np.array([r[5] for r in ok], dtype=float)

    # Find max-error point
    imax = int(np.argmax(rels)) if len(rels) else None
    worst = ok[imax] if imax is not None else None

    report = []
    report.append(f"Validation domain: E=[{args.Emin},{args.Emax}] keV, kT=[{args.kTmin},{args.kTmax}] keV")
    report.append(f"Points tested: {len(pts)} (random={len(rand_pts)}, corner={len(corner_pts)})")
    report.append(f"Exact epsrel={args.epsrel}")
    report.append(f"alpha_min mask={args.alpha_min}")
    report.append(f"OK points: {len(ok)} | ignored(underflow): {ignored} | bad(nonfinite/nonpos): {bad}")
    report.append(f"Runtime exact evals: {len(pts)} in {t1-t0:.2f}s (~{len(pts)/(t1-t0):.1f} eval/s)")
    if len(ok):
        report.append(f"max|relerr| = {float(np.max(rels)):.6e}")
        report.append(f"p99|relerr| = {float(np.quantile(rels,0.99)):.6e}")
        report.append(f"median|relerr| = {float(np.median(rels)):.6e}")
        report.append(f"max|logerr| = {float(np.max(loges)):.6e}  (exp-1 ~ {float(np.expm1(np.max(loges))):.6e})")
        if worst:
            E,kT,exact,approx,rel,loge,_ = worst
            report.append("Worst point (among OK):")
            report.append(f"  E={E:.6g} keV, kT={kT:.6g} keV")
            report.append(f"  exact={exact:.6e}, approx={approx:.6e}")
            report.append(f"  relerr={rel:.6e}, logerr={loge:.6e}")
    else:
        report.append("No OK points (check alpha_min / model positivity).")

    Path(args.out).write_text("\n".join(report) + "\n")
    print("\n".join(report))

if __name__ == "__main__":
    main()
