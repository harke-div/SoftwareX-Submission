#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

def _import_exact():
    try:
        from exact import alpha_gg as f
        return f
    except Exception:
        pass
    try:
        from exact import alpha_gg_exact as f
        return f
    except Exception:
        pass
    raise ImportError("Could not import exact evaluator. Expected gg_pair_exact.alpha_gg or alpha_gg_exact")

def _import_model():
    from approx import alpha_model
    return alpha_model

def log_uniform(rng: np.random.Generator, a: float, b: float, n: int):
    la, lb = np.log(a), np.log(b)
    return np.exp(rng.uniform(la, lb, size=n))

def main():
    ap = argparse.ArgumentParser(description="Impact-weighted error metrics (w=1-exp(-alpha_exact*L)).")
    ap.add_argument("--fit-outdir", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--Emin", type=float, default=300.0)
    ap.add_argument("--Emax", type=float, default=30000.0)
    ap.add_argument("--kTmin", type=float, default=5.0)
    ap.add_argument("--kTmax", type=float, default=300.0)
    ap.add_argument("--N", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--epsrel", type=float, default=3e-4)
    ap.add_argument("--alpha-min", type=float, default=1e-25)
    ap.add_argument("--L", type=float, default=1e6)
    args = ap.parse_args()

    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    params = np.array(json.loads((Path(args.fit_outdir)/"fit_params.json").read_text())["params"], dtype=float)

    alpha_exact = _import_exact()
    alpha_model = _import_model()

    rng = np.random.default_rng(args.seed)
    E = log_uniform(rng, args.Emin, args.Emax, args.N)
    kT = log_uniform(rng, args.kTmin, args.kTmax, args.N)

    a_approx = np.asarray(alpha_model(E, kT, params), dtype=float)
    a_exact = np.empty(args.N, dtype=float)
    for i in range(args.N):
        a_exact[i] = float(alpha_exact(float(E[i]), float(kT[i]), epsrel=args.epsrel))

    ok = np.isfinite(a_exact) & np.isfinite(a_approx) & (a_approx > 0) & (a_exact > args.alpha_min)
    rel = np.full(args.N, np.nan, float)
    rel[ok] = np.abs((a_approx[ok]-a_exact[ok]) / a_exact[ok])

    tau = np.full(args.N, np.nan, float)
    tau[ok] = a_exact[ok] * args.L
    tau_clip = np.clip(tau[ok], 0, 700)
    w = np.full(args.N, np.nan, float)
    w[ok] = 1.0 - np.exp(-tau_clip)

    wsum = float(np.nansum(w))
    wmean = float(np.nansum(w * rel) / max(wsum, 1e-300)) if wsum > 0 else float("nan")
    wrms = float(np.sqrt(np.nansum(w * (rel**2)) / max(wsum, 1e-300))) if wsum > 0 else float("nan")

    s = []
    s.append("Impact-weighted error metrics")
    s.append(f"Domain: E=[{args.Emin},{args.Emax}] keV, kT=[{args.kTmin},{args.kTmax}] keV")
    s.append(f"N={args.N}, epsrel={args.epsrel}, alpha_min={args.alpha_min:g}, L={args.L:g} cm")
    s.append(f"OK points={int(np.sum(ok))} (excluded {args.N-int(np.sum(ok))})")
    s.append(f"weighted mean relerr={wmean:.6e}")
    s.append(f"weighted RMS  relerr={wrms:.6e}")
    (outdir/"summary.txt").write_text("\n".join(s)+"\n", encoding="utf-8")

    # Plot
    try:
        plt.figure()
        sc = plt.scatter(a_exact[ok], rel[ok], c=w[ok], s=6)
        plt.xscale("log"); plt.yscale("log")
        plt.xlabel(r"$\alpha_{\rm exact}$ (cm$^{-1}$)")
        plt.ylabel("relative error")
        cb = plt.colorbar(sc)
        cb.set_label(r"$w=1-e^{-\alpha L}$")
        plt.title("Impact-weighted view of errors")
        plt.tight_layout()
        plt.savefig(outdir/"relerr_vs_alpha_colored_by_weight.png", dpi=200)
        plt.close()
    except Exception:
        pass

    np.savez(outdir/"impact_samples.npz", E_keV=E, kT_keV=kT, alpha_exact=a_exact, alpha_approx=a_approx, relerr=rel, weight=w, ok_mask=ok)
    print("Wrote:", outdir)

if __name__ == "__main__":
    main()
