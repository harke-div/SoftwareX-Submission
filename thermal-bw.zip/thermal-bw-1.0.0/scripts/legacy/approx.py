from __future__ import annotations
import numpy as np

ME_C2_KEV = 511.0

def alpha_model(E_keV, kT_keV, params):
    """Analytic approximation for thermally averaged Breit–Wheeler absorption alpha_gg(E,kT).

    Model variables:
      x = E/(m_e c^2),  t = kT/(m_e c^2),  eta = x*t

    Model form (vectorized; only exp/log/pow):
      alpha = A * kT^3 * exp( - (a/eta)^q ) * eta^(p-1) * log(1 + b*eta)
              / ( 1 + c * eta^p * (1 + d*eta)^r )

    Parameters:
      params = [logA, logb, logc, logd, p, a, q, r]
        A,b,c,d > 0 via logs; p,a,q real with q>0; r real.
    """
    logA, logb, logc, logd, p, a, q, r = [float(x) for x in params]
    A = np.exp(logA)
    b = np.exp(logb)
    c = np.exp(logc)
    d = np.exp(logd)

    E_keV = np.asarray(E_keV, dtype=float)
    kT_keV = np.asarray(kT_keV, dtype=float)

    eta = (E_keV/ME_C2_KEV) * (kT_keV/ME_C2_KEV)
    eta_pos = np.maximum(eta, 1e-30)

    S = np.exp(- (a/eta_pos)**q )
    L = np.log1p(b*eta_pos)
    num = (eta_pos**(p-1.0)) * L
    den = 1.0 + c*(eta_pos**p) * (1.0 + d*eta_pos)**r

    return A * (kT_keV**3) * S * num / den
