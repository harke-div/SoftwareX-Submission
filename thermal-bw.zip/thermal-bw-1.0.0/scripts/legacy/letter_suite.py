#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, time
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import sys

ME_C2_KEV = 511.0

def _import_exact():
    try:
        from exact import alpha_gg as f
        return f
    except Exception:
        pass
    try:
        from exact import alpha_gg_exact as f
        return f
    except Exception:
        pass
    raise ImportError("Could not import alpha_gg or alpha_gg_exact from exact.py")

def _import_model():
    from approx import alpha_model
    return alpha_model

def alpha_baseline(E_keV, kT_keV, params):
    '''
    Fast baseline to compare against fitted model.

      eta = (E/511)*(kT/511)
      alpha_base = A * exp(-a/eta) * log(1 + b*eta) / eta

    params = [logA, logb, a]
    '''
    logA, logb, a = [float(x) for x in params]
    A = np.exp(logA); b = np.exp(logb)

    E_keV = np.asarray(E_keV, dtype=float)
    kT_keV = np.asarray(kT_keV, dtype=float)

    eta = (E_keV/ME_C2_KEV) * (kT_keV/ME_C2_KEV)
    eta = np.maximum(eta, 1e-30)
    out = A * np.exp(-a/eta) * np.log1p(b*eta) / eta
    return np.maximum(out, 0.0)

def solve_E_escape(E_keV, tau, target=1.0):
    E = np.asarray(E_keV, float)
    t = np.asarray(tau, float)
    m = np.isfinite(t) & (t > 0) & np.isfinite(E) & (E > 0)
    E = E[m]; t = t[m]
    if E.size < 2:
        return np.nan
    idx = np.where((t[:-1] - target) * (t[1:] - target) <= 0)[0]
    if idx.size == 0:
        return np.nan
    i = int(idx[0])
    x0, x1 = np.log(E[i]), np.log(E[i+1])
    y0, y1 = np.log(t[i]), np.log(t[i+1])
    yt = np.log(target)
    if y1 == y0:
        return float(np.exp(0.5*(x0+x1)))
    x = x0 + (yt - y0) * (x1 - x0) / (y1 - y0)
    return float(np.exp(x))

def main():
    ap = argparse.ArgumentParser(description="Letter-ready deliverables: tau(E), E_escape(kT), baseline compare, speed.")
    ap.add_argument("--fit-outdir", required=True, help="Folder containing fit_params.json")
    ap.add_argument("--outdir", required=True, help="Where to write figures + reports")
    ap.add_argument("--L", type=float, default=1e6, help="Path length in cm (default 1e6 cm = 10 km)")
    ap.add_argument("--Emin", type=float, default=300.0, help="keV")
    ap.add_argument("--Emax", type=float, default=30000.0, help="keV (30 MeV)")
    ap.add_argument("--nE", type=int, default=160, help="energy points (log-spaced)")
    ap.add_argument("--kT-list", default="10,50,200,300", help="comma list of kT values (keV) for tau(E) curves")
    ap.add_argument("--kTmin", type=float, default=5.0)
    ap.add_argument("--kTmax", type=float, default=300.0)
    ap.add_argument("--nkT", type=int, default=50, help="number of kT values for E_escape(kT)")
    ap.add_argument("--epsrel", type=float, default=3e-4, help="exact integral tolerance")
    ap.add_argument("--alpha-min", type=float, default=1e-25, help="mask for error reporting")
    ap.add_argument("--speed-N", type=int, default=200000, help="approx eval count for speed test")
    args = ap.parse_args()

    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)

    alpha_gg = _import_exact()
    alpha_model = _import_model()

    params = np.array(json.loads((Path(args.fit_outdir)/"fit_params.json").read_text())["params"], dtype=float)

    # baseline parameters (fixed simple baseline)
    base_params = np.array([np.log(1e2), np.log(1e2), 1.0], float)

    E = np.logspace(np.log10(args.Emin), np.log10(args.Emax), args.nE)
    kT_list = [float(x) for x in args.kT_list.split(",") if x.strip()]
    L = float(args.L)

    # tau(E) plots for selected kT
    tau_reports = []
    for kT in kT_list:
        exact = np.array([alpha_gg(float(Ei), float(kT), epsrel=args.epsrel) for Ei in E], float)
        approx = alpha_model(E, np.full_like(E, kT), params).astype(float)
        base = alpha_baseline(E, np.full_like(E, kT), base_params).astype(float)

        tau_ex = exact * L
        tau_ap = approx * L
        tau_ba = base * L

        plt.figure(figsize=(6.6,4.6))
        plt.loglog(E, np.maximum(tau_ex, 1e-300), label="exact")
        plt.loglog(E, np.maximum(tau_ap, 1e-300), "--", label="approx (this work)")
        plt.loglog(E, np.maximum(tau_ba, 1e-300), ":", label="baseline")
        plt.axhline(1.0, linewidth=1.0)
        plt.xlabel("E (keV)")
        plt.ylabel(r"$\tau_{\gamma\gamma}(E)=\alpha(E,kT)\,L$")
        plt.title(f"Optical depth vs E, kT={kT:g} keV, L={L:.1e} cm")
        plt.legend()
        plt.tight_layout()
        plt.savefig(outdir/f"tau_vs_E_kT_{kT:g}keV.png", dpi=200)
        plt.close()

        m = np.isfinite(exact) & np.isfinite(approx) & (exact > args.alpha_min) & (approx > 0)
        rel = np.full_like(exact, np.nan)
        rel[m] = np.abs((approx[m] - exact[m]) / exact[m])

        plt.figure(figsize=(6.6,4.2))
        if np.any(m):
            plt.semilogx(E[m], rel[m])
        plt.xlabel("E (keV)")
        plt.ylabel("relative error in alpha")
        plt.title(f"Relerr(alpha) vs E (mask alpha>{args.alpha_min:g}), kT={kT:g} keV")
        plt.tight_layout()
        plt.savefig(outdir/f"relerr_alpha_vs_E_kT_{kT:g}keV.png", dpi=200)
        plt.close()

        tau_reports.append({
            "kT_keV": kT,
            "E_escape_exact_keV": solve_E_escape(E, tau_ex, 1.0),
            "E_escape_approx_keV": solve_E_escape(E, tau_ap, 1.0),
            "E_escape_baseline_keV": solve_E_escape(E, tau_ba, 1.0),
        })

    # E_escape(kT) sweep
    kT_grid = np.logspace(np.log10(args.kTmin), np.log10(args.kTmax), args.nkT)
    Eesc_exact = np.full_like(kT_grid, np.nan, dtype=float)
    Eesc_approx = np.full_like(kT_grid, np.nan, dtype=float)
    Eesc_base  = np.full_like(kT_grid, np.nan, dtype=float)

    for i, kT in enumerate(kT_grid):
        exact = np.array([alpha_gg(float(Ei), float(kT), epsrel=args.epsrel) for Ei in E], float)
        approx = alpha_model(E, np.full_like(E, kT), params).astype(float)
        base = alpha_baseline(E, np.full_like(E, kT), base_params).astype(float)
        Eesc_exact[i] = solve_E_escape(E, exact*L, 1.0)
        Eesc_approx[i] = solve_E_escape(E, approx*L, 1.0)
        Eesc_base[i] = solve_E_escape(E, base*L, 1.0)

    plt.figure(figsize=(6.6,4.6))
    plt.loglog(kT_grid, Eesc_exact, label="exact")
    plt.loglog(kT_grid, Eesc_approx, "--", label="approx (this work)")
    plt.loglog(kT_grid, Eesc_base, ":", label="baseline")
    plt.xlabel("kT (keV)")
    plt.ylabel(r"$E_{\rm esc}$ (keV) where $\tau(E)=1$")
    plt.title(f"Escape energy vs temperature (L={L:.1e} cm)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outdir/"Eescape_vs_kT.png", dpi=200)
    plt.close()

    # Speed benchmark
    N = int(args.speed_N)
    rng = np.random.default_rng(0)
    E_s = np.exp(rng.uniform(np.log(args.Emin), np.log(args.Emax), size=N))
    T_s = np.exp(rng.uniform(np.log(args.kTmin), np.log(args.kTmax), size=N))

    t0 = time.perf_counter()
    _ = alpha_model(E_s, T_s, params)
    t1 = time.perf_counter()
    approx_rate = N/(t1-t0)

    M = 200
    E_m = np.exp(rng.uniform(np.log(args.Emin), np.log(args.Emax), size=M))
    T_m = np.exp(rng.uniform(np.log(args.kTmin), np.log(args.kTmax), size=M))
    t0 = time.perf_counter()
    for j in range(M):
        _ = alpha_gg(float(E_m[j]), float(T_m[j]), epsrel=args.epsrel)
    t1 = time.perf_counter()
    exact_rate = M/(t1-t0)

    report = {
        "fit_outdir": str(args.fit_outdir),
        "L_cm": L,
        "domain": {"E_keV":[args.Emin,args.Emax], "kT_keV":[args.kTmin,args.kTmax]},
        "alpha_min_mask": args.alpha_min,
        "tau_E_curves_kT_keV": kT_list,
        "E_escape_samples": tau_reports,
        "E_escape_kT_grid": {
            "kT_keV": kT_grid.tolist(),
            "Eesc_exact_keV": Eesc_exact.tolist(),
            "Eesc_approx_keV": Eesc_approx.tolist(),
            "Eesc_baseline_keV": Eesc_base.tolist(),
        },
        "speed": {
            "approx_eval_per_s": approx_rate,
            "exact_eval_per_s": exact_rate,
            "approx_N": N,
            "exact_M": M,
            "epsrel": args.epsrel
        }
    }
    (outdir/"letter_suite_report.json").write_text(json.dumps(report, indent=2))

    print("Wrote letter-ready outputs to:", outdir)
    print(f"Speed: approx {approx_rate:.2e} eval/s; exact {exact_rate:.2e} eval/s")

if __name__ == "__main__":
    main()
