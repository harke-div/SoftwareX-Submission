
"""
Exact value for gamma-gamma (Breit–Wheeler) pair production absorption
coefficient alpha_gg(E, kT) for a test photon of energy E propagating through an
isotropic blackbody photon field at temperature kT (both in keV).

ONLY a reference implementation for fitting a fast approximation
alpha_approx(E,kT) usable in opacity/Rosseland integrations.

Physics (dimensionless):
  x = E / (m_e c^2)
  y = eps / (m_e c^2)
  mu = cos(theta) between photons

Threshold: x*y*(1-mu) >= 2

Breit–Wheeler cross section:
  beta = sqrt(1 - 2 / (x*y*(1-mu)))
  sigma(beta) = (3/16) * sigma_T * (1-beta^2) *
    [ (3-beta^4) ln((1+beta)/(1-beta)) - 2 beta (2-beta^2) ]

Absorption coefficient (isotropic target field):
  alpha_gg(x) = (1/2) ∫_{-1}^{1} dmu (1-mu) ∫_0^∞ d eps n_bb(eps;T) sigma(s)

where n_bb(eps) is number density per energy [cm^-3 erg^-1].

Implementation notes:
- Uses scipy.integrate.quad. SLOW
- Integrates eps via dimensionless u = eps/(kT), truncating at u_max (default 80).
Planck spectrum decays exponentially at large u so it is SAFE
- Alpha in units cm^-1.

Dependencies: numpy, scipy
from __future__ import annotations
"""

import math
import numpy as np
from scipy import integrate

# --- CGS constants ---
C_CGS = 2.99792458e10          # cm/s
H_CGS = 6.62607015e-27         # erg*s
ME_C2_KEV = 511.0              # keV
KEV_TO_ERG = 1.602176634e-9    # erg/keV
SIGMA_T = 6.6524587321e-25     # cm^2
PI = math.pi


def sigma_breit_wheeler(beta: float) -> float:
    """Breit–Wheeler gamma-gamma -> e+e- cross section [cm^2] as function of beta in (0,1)."""
    if beta <= 0.0:
        return 0.0
    if beta >= 1.0:
        beta = 1.0 - 1e-15
    b2 = beta * beta
    one_minus_b2 = 1.0 - b2
    lnterm = math.log((1.0 + beta) / (1.0 - beta))
    bracket = (3.0 - beta**4) * lnterm - 2.0 * beta * (2.0 - b2)
    return (3.0 / 16.0) * SIGMA_T * one_minus_b2 * bracket


def n_bb_eps(eps_erg: float, kT_erg: float) -> float:
    """
    Blackbody photon number density per unit energy n(eps) [cm^-3 erg^-1] for isotropic Planck field.
      n(eps) = (8*pi)/(h^3 c^3) * eps^2 / (exp(eps/kT)-1)
    Here kT_erg is (k_B T) in erg (i.e. energy units).
    """
    if eps_erg <= 0.0:
        return 0.0
    x = eps_erg / kT_erg
    denom = math.expm1(x)
    if denom == 0.0:
        return 0.0
    pref = (8.0 * PI) / (H_CGS**3 * C_CGS**3)
    return pref * eps_erg**2 / denom


def alpha_gg(E_keV: float, kT_keV: float, u_max: float = 80.0,
             epsabs: float = 0.0, epsrel: float = 3e-4) -> float:
    """
    Absorption coefficient alpha_gg [cm^-1] for test photon energy E_keV in isotropic blackbody at kT_keV.
    """
    if E_keV <= 0.0 or kT_keV <= 0.0:
        return 0.0

    x = E_keV / ME_C2_KEV  # dimensionless
    kT_erg = kT_keV * KEV_TO_ERG

    def inner_eps(mu: float) -> float:
        one_minus_mu = 1.0 - mu
        if one_minus_mu <= 0.0:
            return 0.0
        y_thr = 2.0 / (x * one_minus_mu)
        eps_thr_erg = y_thr * ME_C2_KEV * KEV_TO_ERG
        u_thr = eps_thr_erg / kT_erg
        if u_thr >= u_max:
            return 0.0

        def integrand_u(u: float) -> float:
            eps_erg = u * kT_erg
            y = (eps_erg / KEV_TO_ERG) / ME_C2_KEV
            s = x * y * one_minus_mu
            if s <= 2.0:
                return 0.0
            beta = math.sqrt(1.0 - 2.0 / s)
            sig = sigma_breit_wheeler(beta)
            n_eps = n_bb_eps(eps_erg, kT_erg)
            return n_eps * sig * kT_erg  # d eps = kT * du

        val, _ = integrate.quad(integrand_u, u_thr, u_max, epsabs=epsabs, epsrel=epsrel, limit=200)
        return val

    def integrand_mu(mu: float) -> float:
        return 0.5 * (1.0 - mu) * inner_eps(mu)

    val, _ = integrate.quad(integrand_mu, -1.0, 1.0, epsabs=epsabs, epsrel=epsrel, limit=200)
    return float(val)


def alpha_grid(E_keV: np.ndarray, kT_keV: np.ndarray, **kwargs) -> np.ndarray:
    """Compute alpha_gg on a meshgrid of E and kT (slow). Returns (len(kT), len(E))."""
    E_keV = np.asarray(E_keV, dtype=float)
    kT_keV = np.asarray(kT_keV, dtype=float)
    out = np.zeros((len(kT_keV), len(E_keV)), dtype=float)
    for i, T in enumerate(kT_keV):
        for j, E in enumerate(E_keV):
            out[i, j] = alpha_gg(float(E), float(T), **kwargs)
    return out
