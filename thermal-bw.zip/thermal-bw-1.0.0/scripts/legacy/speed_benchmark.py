#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, time
from pathlib import Path
import numpy as np
from approx import alpha_model
from exact import alpha_gg

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--N", type=int, default=200000)
    ap.add_argument("--M", type=int, default=20)
    args = ap.parse_args()

    outdir = Path(args.outdir)
    params = np.array(json.loads((outdir/'fit_params.json').read_text())['params'], dtype=float)

    N=int(args.N)
    E = np.exp(np.random.uniform(np.log(300.0), np.log(3e4), size=N))
    kT = np.exp(np.random.uniform(np.log(5.0), np.log(300.0), size=N))

    t0=time.perf_counter()
    _=alpha_model(E, kT, params)
    t1=time.perf_counter()
    print(f"alpha_model: {N} evals in {t1-t0:.3f} s ({N/(t1-t0):.2e} eval/s)")

    M=int(args.M)
    E2=np.linspace(1e3,2e4,M)
    T2=np.linspace(10.0,300.0,M)
    t0=time.perf_counter()
    for i in range(M):
        _=alpha_gg(float(E2[i]), float(T2[i]))
    t1=time.perf_counter()
    print(f"alpha_gg exact: {M} evals in {t1-t0:.3f} s ({M/(t1-t0):.2e} eval/s)")

if __name__=='__main__':
    main()
