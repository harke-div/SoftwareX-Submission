#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

def _import_exact():
    try:
        from exact import alpha_gg as f
        return f
    except Exception:
        pass
    try:
        from exact import alpha_gg_exact as f
        return f
    except Exception:
        pass
    raise ImportError("Could not import exact evaluator. Expected gg_pair_exact.alpha_gg or alpha_gg_exact")

def _import_model():
    from approx import alpha_model
    return alpha_model

def log_uniform(rng: np.random.Generator, a: float, b: float, n: int):
    la, lb = np.log(a), np.log(b)
    return np.exp(rng.uniform(la, lb, size=n))

def main():
    ap = argparse.ArgumentParser(description="Monte Carlo stress test + impact-weighted error metrics.")
    ap.add_argument("--fit-outdir", required=True, help="Folder with fit_params.json")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--Emin", type=float, default=300.0)
    ap.add_argument("--Emax", type=float, default=30000.0)
    ap.add_argument("--kTmin", type=float, default=5.0)
    ap.add_argument("--kTmax", type=float, default=300.0)
    ap.add_argument("--N", type=int, default=5000, help="MC points (loose exact)")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--epsrel-loose", type=float, default=1e-3)
    ap.add_argument("--epsrel-tight", type=float, default=3e-6)
    ap.add_argument("--K", type=int, default=60, help="Top-K worst points to re-evaluate with tight exact")
    ap.add_argument("--alpha-min", type=float, default=1e-25, help="Mask exact alpha <= this")
    ap.add_argument("--L", type=float, default=1e6, help="cm; used only for impact weights w=1-exp(-alpha*L)")
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    params = np.array(json.loads((Path(args.fit_outdir)/"fit_params.json").read_text())["params"], dtype=float)

    alpha_exact = _import_exact()
    alpha_model = _import_model()

    rng = np.random.default_rng(args.seed)
    E = log_uniform(rng, args.Emin, args.Emax, args.N)
    kT = log_uniform(rng, args.kTmin, args.kTmax, args.N)

    # Approx (vectorized)
    a_approx = np.asarray(alpha_model(E, kT, params), dtype=float)

    # Exact loose
    a_exact_loose = np.empty(args.N, dtype=float)
    for i in range(args.N):
        a_exact_loose[i] = float(alpha_exact(float(E[i]), float(kT[i]), epsrel=args.epsrel_loose))

    ok = np.isfinite(a_exact_loose) & np.isfinite(a_approx) & (a_approx > 0) & (a_exact_loose > args.alpha_min)

    rel = np.full(args.N, np.nan, dtype=float)
    rel[ok] = np.abs((a_approx[ok] - a_exact_loose[ok]) / a_exact_loose[ok])

    # Impact weights
    tau = np.full(args.N, np.nan, dtype=float)
    tau[ok] = a_exact_loose[ok] * args.L
    w = np.full(args.N, np.nan, dtype=float)
    tau_clip = np.clip(tau[ok], 0, 700)  # avoid exp overflow
    w[ok] = 1.0 - np.exp(-tau_clip)

    rel_ok = rel[ok]
    max_rel = float(np.max(rel_ok)) if rel_ok.size else float("nan")
    p99 = float(np.quantile(rel_ok, 0.99)) if rel_ok.size else float("nan")
    med = float(np.median(rel_ok)) if rel_ok.size else float("nan")

    wsum = float(np.nansum(w))
    wmean = float(np.nansum(w * rel) / max(wsum, 1e-300)) if wsum > 0 else float("nan")
    wrms = float(np.sqrt(np.nansum(w * (rel**2)) / max(wsum, 1e-300))) if wsum > 0 else float("nan")

    # Tight recomputation at worst K points (by loose relerr)
    ok_idx = np.where(ok)[0]
    if rel_ok.size:
        worst_local = np.argsort(rel_ok)[-min(args.K, rel_ok.size):]
        worst_idx = ok_idx[worst_local]
    else:
        worst_idx = np.array([], dtype=int)

    rows = []
    for j in worst_idx[np.argsort(rel[worst_idx])[::-1]]:
        ex_t = float(alpha_exact(float(E[j]), float(kT[j]), epsrel=args.epsrel_tight))
        apx = float(a_approx[j])
        rel_t = abs((apx - ex_t)/ex_t) if ex_t > 0 else float("nan")
        rows.append((float(E[j]), float(kT[j]), float(a_exact_loose[j]), ex_t, apx, float(rel[j]), rel_t))

    csv_path = outdir/"mc_worst_tight.csv"
    with csv_path.open("w", encoding="utf-8") as f:
        f.write("E_keV,kT_keV,alpha_exact_loose,alpha_exact_tight,alpha_approx,relerr_loose,relerr_tight\n")
        for r in rows:
            f.write(",".join(f"{x:.6e}" if (isinstance(x,float) and math.isfinite(x)) else str(x) for x in r) + "\n")

    np.savez(outdir/"mc_points_loose.npz",
             E_keV=E, kT_keV=kT,
             alpha_exact_loose=a_exact_loose,
             alpha_approx=a_approx,
             relerr_loose=rel,
             tau_L=tau,
             weight=w,
             ok_mask=ok)

    # Scatter relerr vs alpha_exact
    try:
        plt.figure()
        plt.loglog(a_exact_loose[ok], rel_ok, ".", markersize=2)
        plt.axvline(args.alpha_min, linestyle="--")
        plt.xlabel(r"$\alpha_{\rm exact}$ (cm$^{-1}$)")
        plt.ylabel("relative error (loose exact)")
        plt.title(f"MC stress (N={args.N}), alpha_min={args.alpha_min:g}")
        plt.tight_layout()
        plt.savefig(outdir/"relerr_vs_alpha.png", dpi=200)
        plt.close()
    except Exception:
        pass

    summary = []
    summary.append("Monte Carlo stress test")
    summary.append(f"Domain: E=[{args.Emin},{args.Emax}] keV, kT=[{args.kTmin},{args.kTmax}] keV (log-uniform)")
    summary.append(f"N={args.N}, seed={args.seed}")
    summary.append(f"epsrel_loose={args.epsrel_loose}, epsrel_tight={args.epsrel_tight}")
    summary.append(f"alpha_min={args.alpha_min:g}")
    summary.append(f"OK points={int(np.sum(ok))} (excluded {args.N-int(np.sum(ok))})")
    summary.append("")
    summary.append("Relerr (loose exact) over OK:")
    summary.append(f"  max   = {max_rel:.6e}")
    summary.append(f"  p99   = {p99:.6e}")
    summary.append(f"  median= {med:.6e}")
    summary.append("")
    summary.append(f"Impact-weighted (L={args.L:g} cm, w=1-exp(-alpha*L)):")
    summary.append(f"  weighted mean relerr = {wmean:.6e}")
    summary.append(f"  weighted RMS  relerr = {wrms:.6e}")
    summary.append("")
    summary.append(f"Worst K={len(rows)} points re-evaluated with tight exact saved to mc_worst_tight.csv")
    (outdir/"summary.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")

    print("Wrote:", outdir)

if __name__ == "__main__":
    main()
