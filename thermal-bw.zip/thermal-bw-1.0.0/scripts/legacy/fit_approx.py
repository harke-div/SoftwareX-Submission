#!/usr/bin/env python3
from __future__ import annotations

import argparse, json
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
import matplotlib.pyplot as plt

from exact import alpha_grid
from approx import alpha_model

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Emin", type=float, default=300.0)
    ap.add_argument("--Emax", type=float, default=30000.0)
    ap.add_argument("--nE", type=int, default=25)
    ap.add_argument("--kTmin", type=float, default=5.0)
    ap.add_argument("--kTmax", type=float, default=300.0)
    ap.add_argument("--nT", type=int, default=12)
    ap.add_argument("--u-max", type=float, default=80.0)
    ap.add_argument("--epsrel", type=float, default=3e-4)
    ap.add_argument("--alpha-min", type=float, default=1e-120, help="mask threshold for alpha_exact")
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    E = np.logspace(np.log10(args.Emin), np.log10(args.Emax), args.nE)
    kT = np.logspace(np.log10(args.kTmin), np.log10(args.kTmax), args.nT)

    alpha_exact = alpha_grid(E, kT, u_max=args.u_max, epsrel=args.epsrel)  # (nT,nE)

    EE = E[None, :]      # (1,nE)
    TT = kT[:, None]     # (nT,1)
    y = alpha_exact

    mask = np.isfinite(y) & (y > args.alpha_min)
    logy = np.zeros_like(y)
    logy[mask] = np.log(y[mask])

    # params = [logA, logb, logc, logd, p, a, q, r]
    p0 = np.array([np.log(1e-40), np.log(1.0), np.log(1.0), np.log(1.0), 2.0, 1.0, 1.0, 0.5], dtype=float)
    lb = np.array([np.log(1e-120), np.log(1e-12), np.log(1e-12), np.log(1e-12), 0.2, 1e-6, 0.2, -5.0], dtype=float)
    ub = np.array([np.log(1e40), np.log(1e12), np.log(1e12), np.log(1e12), 10.0, 100.0, 5.0,  5.0], dtype=float)

    def resid(params):
        yhat = alpha_model(EE, TT, params)
        r = (np.log(yhat[mask] + 1e-300) - logy[mask])
        return r.ravel()

    res = least_squares(resid, p0, bounds=(lb, ub), max_nfev=2000)
    params = res.x
    yhat = alpha_model(EE, TT, params)

    valid = np.isfinite(y) & np.isfinite(yhat) & (y > args.alpha_min) & (yhat > 0)
    relerr = np.abs((yhat[valid] - y[valid]) / y[valid])
    max_rel = float(np.max(relerr)) if valid.any() else float("nan")
    p99_rel = float(np.quantile(relerr, 0.99)) if valid.any() else float("nan")
    excluded = int(y.size - int(np.sum(valid)))

    (outdir/"fit_params.json").write_text(json.dumps({
        "params": params.tolist(),
        "param_names": ["logA","logb","logc","logd","p","a","q","r"],
        "cost": float(res.cost),
        "success": bool(res.success),
        "message": res.message,
        "alpha_min_mask": float(args.alpha_min),
        "max_relerr_valid": max_rel,
        "p99_relerr_valid": p99_rel,
        "n_valid": int(np.sum(valid)),
        "n_total": int(y.size),
    }, indent=2))

    np.savez(outdir/"dataset.npz", E_keV=E, kT_keV=kT, alpha_exact=alpha_exact, alpha_pred=yhat)

    # Heatmap for relative error (clipped)
    rel_map = np.full_like(y, np.nan, dtype=float)
    rel_map[valid] = (yhat[valid] - y[valid]) / y[valid]
    plt.figure()
    plt.imshow(np.clip(rel_map, -1, 1), aspect="auto", origin="lower",
               extent=[np.log10(E[0]), np.log10(E[-1]), np.log10(kT[0]), np.log10(kT[-1])])
    plt.colorbar(label="(approx-exact)/exact (clipped ±1)")
    plt.xlabel("log10 E_keV"); plt.ylabel("log10 kT_keV")
    plt.title("Relative error heatmap (valid mask; clipped)")
    plt.tight_layout()
    plt.savefig(outdir/"relerr_heatmap.png", dpi=200)
    plt.close()

    (outdir/"summary.txt").write_text(
        f"valid mask: alpha_exact > {args.alpha_min}\n"
        f"max|relerr| (valid) = {max_rel:.6e}\n"
        f"p99|relerr| (valid) = {p99_rel:.6e}\n"
        f"valid points = {int(np.sum(valid))}/{y.size}\n"
        f"excluded points = {excluded}/{y.size}\n"
    )

    print(f"Fit complete. max|relerr|={max_rel:.3e}, p99|relerr|={p99_rel:.3e} (valid mask; excluded {excluded}/{y.size})")

if __name__ == "__main__":
    main()
