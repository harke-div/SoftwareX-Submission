#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

def _import_exact():
    try:
        from exact import alpha_gg as f
        return f
    except Exception:
        pass
    try:
        from exact import alpha_gg_exact as f
        return f
    except Exception:
        pass
    raise ImportError("Could not import exact evaluator. Expected gg_pair_exact.alpha_gg or alpha_gg_exact")

def parse_list(s: str):
    return [float(x) for x in s.split(",") if x.strip()]

def main():
    ap = argparse.ArgumentParser(description="Exact-solver convergence/trust test.")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--points-from", default=None, help="CSV with E_keV,kT_keV columns (e.g. mc_worst_tight.csv)")
    ap.add_argument("--E-list", default="300,600,1000,3000,10000,30000")
    ap.add_argument("--kT-list", default="5,10,50,200,300")
    ap.add_argument("--epsrel-list", default="1e-3,3e-4,1e-4,3e-5,1e-5")
    ap.add_argument("--max-points", type=int, default=25)
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    alpha_exact = _import_exact()
    eps_list = parse_list(args.epsrel_list)

    pts = []
    if args.points_from:
        with Path(args.points_from).open("r", encoding="utf-8") as f:
            rd = csv.DictReader(f)
            for row in rd:
                pts.append((float(row["E_keV"]), float(row["kT_keV"])))
        # unique and cap
        uniq, seen = [], set()
        for E,kT in pts:
            key = (round(E,6), round(kT,6))
            if key not in seen:
                uniq.append((E,kT)); seen.add(key)
            if len(uniq) >= args.max_points:
                break
        pts = uniq
    else:
        E_list = parse_list(args.E_list)
        kT_list = parse_list(args.kT_list)
        for kT in kT_list:
            for E in E_list:
                pts.append((E,kT))

    vals = np.zeros((len(pts), len(eps_list)), dtype=float)
    for i,(E,kT) in enumerate(pts):
        for j,eps in enumerate(eps_list):
            vals[i,j] = float(alpha_exact(float(E), float(kT), epsrel=float(eps)))

    ref = vals[:, -1]
    relchg = np.abs((vals - ref[:,None]) / np.maximum(ref[:,None], 1e-300))

    # Save table
    header = ["E_keV","kT_keV"] + [f"alpha_eps{eps:g}" for eps in eps_list] + [f"relchg_eps{eps:g}" for eps in eps_list[:-1]]
    lines = []
    for i,(E,kT) in enumerate(pts):
        row = [f"{E:.6g}", f"{kT:.6g}"] + [f"{vals[i,j]:.6e}" for j in range(len(eps_list))] + [f"{relchg[i,j]:.3e}" for j in range(len(eps_list)-1)]
        lines.append(",".join(row))
    (outdir/"exact_convergence.csv").write_text(",".join(header)+"\n"+"\n".join(lines)+"\n", encoding="utf-8")

    worst = np.max(relchg[:, :-1], axis=0) if len(eps_list) > 1 else np.array([])
    if worst.size:
        plt.figure()
        plt.loglog(eps_list[:-1], worst, marker="o")
        plt.gca().invert_xaxis()
        plt.xlabel("epsrel")
        plt.ylabel("worst rel change vs tightest epsrel")
        plt.title("Exact-solver convergence (worst across points)")
        plt.tight_layout()
        plt.savefig(outdir/"exact_convergence_worst.png", dpi=200)
        plt.close()

    s = []
    s.append(f"Exact convergence test over {len(pts)} points")
    s.append(f"epsrel list: {eps_list}")
    if worst.size:
        for e,w in zip(eps_list[:-1], worst):
            s.append(f"epsrel={e:g}: worst relchg={float(w):.3e}")
    (outdir/"summary.txt").write_text("\n".join(s)+"\n", encoding="utf-8")
    print("Wrote:", outdir)

if __name__ == "__main__":
    main()
