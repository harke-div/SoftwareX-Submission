# Scripts

- `reproduce_paper_metrics.py` is a lightweight script that reads archived benchmark products and prints the headline manuscript metrics.
- `comparison_benchmarks_original.py` reproduces the extended shortcut/Chebyshev comparison benchmark used for the manuscript comparison table. It is computationally expensive because it uses direct quadrature reference calls.
- `compactness_benchmark_original.py` reproduces the compactness-normalized optical-depth benchmark. It is also computationally expensive.
- `legacy/` contains the original development scripts used for fitting, exact convergence checks, Monte Carlo stress tests, speed benchmarks, and figure generation. These are included for provenance and reproducibility of the archived results.

For normal package use, import `thermal_bw.alpha_fit` or `thermal_bw.alpha_exact` instead of calling the legacy scripts directly.
