# Validation notes

The analytic surrogate was fitted and validated against direct numerical quadrature of the standard isotropic thermal Breit--Wheeler opacity integral.

Main retained-domain floor:

```text
alpha_exact > 1e-25 cm^-1
```

This floor removes ultra-suppressed points where relative error is dominated by physically negligible opacity values.

Headline manuscript metrics:

- Dense 100 x 100 grid: maximum relative error 7.4549e-3, 99th percentile 2.4049e-3.
- 5000-point log-uniform Monte Carlo: maximum relative error 7.3711e-3, 99th percentile 2.4029e-3, median 1.5298e-3.
- Scalar throughput benchmark: analytic surrogate 1.48e7 evaluations/s, exact quadrature 1.90e2 evaluations/s, approximate speed ratio 7.8e4.

The comparison benchmark shows that monochromatic delta estimates introduce hard zero-opacity regions where the Planck Wien tail gives nonzero opacity. A simple threshold-tail estimate is positive but can overpredict by more than two orders of magnitude. Chebyshev interpolation is more accurate inside the fitted domain, but it is a table/polynomial surrogate rather than a compact analytic expression.
