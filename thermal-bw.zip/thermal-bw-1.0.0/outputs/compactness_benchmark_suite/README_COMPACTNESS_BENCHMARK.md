# Compactness-normalized benchmark suite

This suite replaces arbitrary optical-depth slabs with a compactness-normalized radiation-column benchmark.

Definition used:

    ell_rad = sigma_T R u_rad / (m_e c^2)

For a diluted blackbody spectral shape, alpha and u_rad scale linearly with dilution W, giving

    tau_gg(E; kT, ell_rad) = alpha_bb(E,kT) * ell_rad*m_e*c^2/(sigma_T*u_bb(kT)).

This benchmark is therefore tied to a standard compact-source radiation compactness rather than an arbitrary path length.
It is not intended as a full source-specific GRB/blazar/corona model.

Global retained-domain relative error summary for tau:

```json
{
  "N": 1256,
  "max": 0.0076312392362353244,
  "p99": 0.002325723943579194,
  "p95": 0.0022744607010885126,
  "median": 0.0014653799951941339,
  "mean": 0.0013922670068132064
}
```

Main files:

- compactness_benchmark_points.csv: all alpha and tau values.
- compactness_benchmark_summary_by_case.csv: error summaries by kT and ell.
- compactness_tau1_boundaries.csv: energy where tau crosses 1 where present.
- compactness_tau_spectra_ell10.png: exact-vs-fit tau spectra.
- compactness_tau_error_ell10.png: percent tau errors.
- compactness_tau1_boundaries.png: tau=1 boundary plot.
