# Comparison benchmark outputs

This directory contains benchmark and demonstration products intended to strengthen the manuscript as an astronomical-computing/methods paper.

## Main files

- `comparison_grid_metrics.csv`: deterministic-grid accuracy/pathology summary.
- `comparison_holdout_metrics.csv`: random-holdout accuracy/pathology summary.
- `comparison_holdout_points.csv`: per-point holdout predictions and errors.
- `comparison_benchmark_summary.json`: machine-readable benchmark summary and interpretation warnings.
- `holdout_error_cdf.png`: cumulative error comparison across shortcut/surrogate methods.
- `scatter_exact_vs_*.png`: exact-vs-predicted scatter checks.
- `optical_depth_demo_points.csv`: optical-depth spectra for simple compact-source demonstrations.
- `optical_depth_demo_summary.json`: optical-depth error metrics.
- `optical_depth_demo_tau.png`: exact vs fit optical-depth spectra.
- `optical_depth_demo_error.png`: propagated tau relative error.

## Methodological caution

Gould & Schreder / Breit-Wheeler quadrature is treated as the direct reference, not as a shortcut approximation. Delta and threshold-tail models are included as representative crude fast estimates because they demonstrate what is lost when the full Planck and angular weighting are collapsed too aggressively. Chebyshev fits are included as black-box interpolation surrogates and should be framed separately from the compact analytic closed form.

## Suggested manuscript framing

The strongest claim supported by these files is not that the closed form is the mathematically most accurate surrogate possible. A Chebyshev interpolant can be more accurate inside the fitted box. The stronger and safer claim is:

> The proposed expression gives sub-percent accuracy while remaining compact, non-negative, branchless, physically scaled, and table-free. Crude monochromatic/threshold estimates show hard cutoff artifacts or order-unity-to-order-of-magnitude errors across the transition regime, while black-box polynomial interpolation trades interpretability and compactness for higher interpolation accuracy.
