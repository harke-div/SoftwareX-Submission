"""Quick regression tests for thermal-bw.

Run with:
    python tests/test_basic.py
"""
from __future__ import annotations

import numpy as np

from thermal_bw import alpha_exact, alpha_fit, within_validated_domain


def test_alpha_fit_scalar_positive():
    alpha = float(alpha_fit(E_MeV=2.0, kT_keV=50.0))
    assert np.isfinite(alpha)
    assert alpha > 0.0


def test_alpha_fit_vectorized_shape_and_nonnegative():
    E = np.logspace(np.log10(0.3), np.log10(30.0), 16)
    alpha = alpha_fit(E_MeV=E, kT_keV=50.0)
    assert alpha.shape == E.shape
    assert np.all(np.isfinite(alpha))
    assert np.all(alpha >= 0.0)


def test_validated_domain_mask():
    assert bool(within_validated_domain(1.0, 50.0))
    assert not bool(within_validated_domain(0.1, 50.0))
    assert not bool(within_validated_domain(1.0, 500.0))


def test_exact_spot_check_reasonable_agreement():
    approx = float(alpha_fit(E_MeV=2.0, kT_keV=50.0))
    exact = float(alpha_exact(E_MeV=2.0, kT_keV=50.0, epsrel=3e-4))
    rel = abs(approx - exact) / exact
    assert rel < 0.01


if __name__ == "__main__":
    tests = [
        test_alpha_fit_scalar_positive,
        test_alpha_fit_vectorized_shape_and_nonnegative,
        test_validated_domain_mask,
        test_exact_spot_check_reasonable_agreement,
    ]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")
