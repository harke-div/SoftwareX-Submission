"""Minimal use of thermal-bw."""
from __future__ import annotations

import numpy as np

from thermal_bw import alpha_exact, alpha_fit, within_validated_domain

# Scalar analytic opacity call.
alpha = alpha_fit(E_MeV=2.0, kT_keV=50.0)
print(f"alpha_fit(2 MeV, 50 keV) = {float(alpha):.6e} cm^-1")

# Vectorized analytic opacity call.
E = np.logspace(np.log10(0.3), np.log10(30.0), 100)
alpha_grid = alpha_fit(E_MeV=E, kT_keV=50.0)
print(f"computed {alpha_grid.size} vectorized opacity values")

# Slow exact reference spot check.
alpha_ref = alpha_exact(E_MeV=2.0, kT_keV=50.0, epsrel=3e-4)
rel = abs(float(alpha) - alpha_ref) / alpha_ref
print(f"alpha_exact(2 MeV, 50 keV) = {alpha_ref:.6e} cm^-1")
print(f"relative error = {rel:.6e}")
print("inside validated domain:", bool(within_validated_domain(2.0, 50.0)))
