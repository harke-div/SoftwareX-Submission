# thermal-bw

`thermal-bw` is a lightweight Python package for exact and approximate thermal Breit--Wheeler opacity calculations in isotropic blackbody radiation fields.

It provides:

- a direct numerical quadrature reference implementation for the standard isotropic angular--energy integral;
- a compact analytic surrogate for repeated opacity calls;
- example scripts for scalar and vectorized use;
- validation scripts and benchmark products supporting the accompanying SoftwareX article.

The archived software release associated with the manuscript is:

**DOI:** https://doi.org/10.5281/zenodo.19435833

## Validated domain

The published analytic surrogate is validated for

- test-photon energy: `E = 0.3--30 MeV`,
- thermal scale: `kT = 5--300 keV`.

The headline validation metrics use the retained-domain floor

```text
alpha_exact > 1e-25 cm^-1
```

because relative error becomes operationally meaningless in ultra-suppressed tails.

## Installation

From the repository root:

```bash
python -m pip install -e .
```

or install dependencies directly:

```bash
python -m pip install -r requirements.txt
```

## Quick start

Scalar opacity call:

```python
from thermal_bw import alpha_fit

alpha = alpha_fit(E_MeV=2.0, kT_keV=50.0)  # cm^-1
print(alpha)
```

Vectorized opacity call:

```python
import numpy as np
from thermal_bw import alpha_fit

E = np.logspace(np.log10(0.3), np.log10(30.0), 100)  # MeV
alpha = alpha_fit(E_MeV=E, kT_keV=50.0)              # cm^-1
```

Direct quadrature reference for spot checks:

```python
from thermal_bw import alpha_exact

alpha_ref = alpha_exact(E_MeV=2.0, kT_keV=50.0, epsrel=3e-4)
```

The direct quadrature routine is slow and is intended for validation, not large sweeps.

## Repository structure

```text
src/thermal_bw/          package source code
examples/                minimal usage examples
scripts/                 validation and benchmark scripts
outputs/                 archived benchmark products used by the manuscript
tests/                   quick regression and sanity checks
docs/                    additional notes
paper/                   manuscript-related files when included
```

## Main validation results

Using the published 100 x 100 log-spaced validation grid and the retained-domain floor `alpha_exact > 1e-25 cm^-1`:

| Test | Maximum relative error | 99th percentile | Median |
|---|---:|---:|---:|
| Dense grid | 7.4549e-3 | 2.4049e-3 | -- |
| Monte Carlo, 5000 points | 7.3711e-3 | 2.4029e-3 | 1.5298e-3 |

The supplied benchmark reports also compare the analytic kernel against representative monochromatic, threshold-tail, and Chebyshev surrogates. Chebyshev interpolation is more accurate inside a fixed rectangle; the analytic surrogate is intended for compact, table-free, branchless use.

## Reproducing key outputs

Quick package sanity check:

```bash
python tests/test_basic.py
```

Run the quick-start example:

```bash
python examples/quickstart.py
```

Regenerate the main published metrics from the archived parameter file:

```bash
python scripts/reproduce_paper_metrics.py --outdir outputs/recomputed_quick
```

The exact 100 x 100 grid and full Monte Carlo reproduction are computationally expensive because they call the direct quadrature evaluator many times. The archived benchmark products are therefore included under `outputs/`.

## Limitations

`thermal-bw` is limited to isotropic, unmagnetized blackbody target fields and unpolarized test photons in the stated validation domain. It does not implement anisotropic fields, non-thermal target spectra, magnetic pair creation, polarization-dependent transfer, or full radiative-transfer propagation.

## License

MIT License.
